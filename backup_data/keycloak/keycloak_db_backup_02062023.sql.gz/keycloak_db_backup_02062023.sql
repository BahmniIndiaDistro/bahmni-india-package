--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


ALTER TABLE public.admin_event_entity OWNER TO keycloak;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO keycloak;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO keycloak;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO keycloak;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO keycloak;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO keycloak;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO keycloak;

--
-- Name: client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO keycloak;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO keycloak;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO keycloak;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO keycloak;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO keycloak;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO keycloak;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO keycloak;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO keycloak;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO keycloak;

--
-- Name: client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


ALTER TABLE public.client_session OWNER TO keycloak;

--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_auth_status OWNER TO keycloak;

--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_note OWNER TO keycloak;

--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_prot_mapper OWNER TO keycloak;

--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_role OWNER TO keycloak;

--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_user_session_note OWNER TO keycloak;

--
-- Name: component; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO keycloak;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


ALTER TABLE public.component_config OWNER TO keycloak;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO keycloak;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO keycloak;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO keycloak;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO keycloak;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO keycloak;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255)
);


ALTER TABLE public.event_entity OWNER TO keycloak;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024)
);


ALTER TABLE public.fed_user_attribute OWNER TO keycloak;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO keycloak;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO keycloak;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO keycloak;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO keycloak;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO keycloak;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO keycloak;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO keycloak;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO keycloak;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO keycloak;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO keycloak;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


ALTER TABLE public.identity_provider OWNER TO keycloak;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO keycloak;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO keycloak;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO keycloak;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


ALTER TABLE public.keycloak_group OWNER TO keycloak;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO keycloak;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO keycloak;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.offline_client_session OWNER TO keycloak;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.offline_user_session OWNER TO keycloak;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO keycloak;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO keycloak;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO keycloak;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO keycloak;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO keycloak;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO keycloak;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO keycloak;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO keycloak;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO keycloak;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO keycloak;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO keycloak;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO keycloak;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO keycloak;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO keycloak;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO keycloak;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO keycloak;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO keycloak;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO keycloak;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode character varying(15) NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO keycloak;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO keycloak;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy character varying(20),
    logic character varying(20),
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO keycloak;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO keycloak;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO keycloak;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO keycloak;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO keycloak;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO keycloak;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO keycloak;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL
);


ALTER TABLE public.user_attribute OWNER TO keycloak;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO keycloak;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO keycloak;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO keycloak;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO keycloak;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO keycloak;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO keycloak;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO keycloak;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO keycloak;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO keycloak;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO keycloak;

--
-- Name: user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


ALTER TABLE public.user_session OWNER TO keycloak;

--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


ALTER TABLE public.user_session_note OWNER TO keycloak;

--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO keycloak;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO keycloak;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
00979f28-54be-40c5-8fac-5506a8a65258	\N	auth-cookie	5ed7970f-211a-4f6b-8938-f50938e90423	aaca34f0-1c81-4ecf-aae1-0ae0b8e03c2e	2	10	f	\N	\N
80a2156a-c3f9-47ee-a89e-ffe4650e7e3f	\N	auth-spnego	5ed7970f-211a-4f6b-8938-f50938e90423	aaca34f0-1c81-4ecf-aae1-0ae0b8e03c2e	3	20	f	\N	\N
77449ed5-6fa7-479c-8446-638ecaea084c	\N	identity-provider-redirector	5ed7970f-211a-4f6b-8938-f50938e90423	aaca34f0-1c81-4ecf-aae1-0ae0b8e03c2e	2	25	f	\N	\N
b8b2e433-4658-4732-bbac-cb1257bdc261	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	aaca34f0-1c81-4ecf-aae1-0ae0b8e03c2e	2	30	t	308cdfea-8ef1-4e1b-b8e5-51c8ad7c749d	\N
c3d3f0eb-812e-4fa1-a730-5fa184e004f5	\N	auth-username-password-form	5ed7970f-211a-4f6b-8938-f50938e90423	308cdfea-8ef1-4e1b-b8e5-51c8ad7c749d	0	10	f	\N	\N
83681c5b-d93a-4d43-b5fd-195c8270540e	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	308cdfea-8ef1-4e1b-b8e5-51c8ad7c749d	1	20	t	661dbc28-2c24-4823-9358-ff7afc637f86	\N
ed44b05e-4001-4c51-b00f-ff6025d4756c	\N	conditional-user-configured	5ed7970f-211a-4f6b-8938-f50938e90423	661dbc28-2c24-4823-9358-ff7afc637f86	0	10	f	\N	\N
d9d99593-02ae-49ee-9913-a9341ded7a01	\N	auth-otp-form	5ed7970f-211a-4f6b-8938-f50938e90423	661dbc28-2c24-4823-9358-ff7afc637f86	0	20	f	\N	\N
705e497c-9858-472d-90b0-cc3e910c7e6e	\N	direct-grant-validate-username	5ed7970f-211a-4f6b-8938-f50938e90423	5f98c1c7-a09a-4d60-885c-b68570411531	0	10	f	\N	\N
09ef172b-0cb6-4251-931f-08f2cc61f6aa	\N	direct-grant-validate-password	5ed7970f-211a-4f6b-8938-f50938e90423	5f98c1c7-a09a-4d60-885c-b68570411531	0	20	f	\N	\N
884abdd6-0ecc-4b72-a0aa-534692ff957c	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	5f98c1c7-a09a-4d60-885c-b68570411531	1	30	t	1acf853b-d8d8-4cea-ac1e-8546b5789fa0	\N
6dd0703b-dff5-4f46-8ea7-c89cf5765a85	\N	conditional-user-configured	5ed7970f-211a-4f6b-8938-f50938e90423	1acf853b-d8d8-4cea-ac1e-8546b5789fa0	0	10	f	\N	\N
f46a26d4-b560-4dde-8e5e-6ab90b00a2e6	\N	direct-grant-validate-otp	5ed7970f-211a-4f6b-8938-f50938e90423	1acf853b-d8d8-4cea-ac1e-8546b5789fa0	0	20	f	\N	\N
27803ac2-0259-4424-a832-015dbdbdfd71	\N	registration-page-form	5ed7970f-211a-4f6b-8938-f50938e90423	5911543b-b1eb-4a6a-82ae-5e76e78113cc	0	10	t	d86a7c98-3f78-4851-bead-9501fcde29ec	\N
2518c6e8-0873-48e1-a89d-17aaa159ab57	\N	registration-user-creation	5ed7970f-211a-4f6b-8938-f50938e90423	d86a7c98-3f78-4851-bead-9501fcde29ec	0	20	f	\N	\N
4bf52d2e-2676-4fde-ad57-14066ef41fc2	\N	registration-profile-action	5ed7970f-211a-4f6b-8938-f50938e90423	d86a7c98-3f78-4851-bead-9501fcde29ec	0	40	f	\N	\N
93f1be25-1965-447d-96e0-39d54a5f16e3	\N	registration-password-action	5ed7970f-211a-4f6b-8938-f50938e90423	d86a7c98-3f78-4851-bead-9501fcde29ec	0	50	f	\N	\N
e5f9ca91-cd2e-4027-8654-a073a72026f5	\N	registration-recaptcha-action	5ed7970f-211a-4f6b-8938-f50938e90423	d86a7c98-3f78-4851-bead-9501fcde29ec	3	60	f	\N	\N
80a0d513-e96e-4e0f-a196-55e42aab0274	\N	reset-credentials-choose-user	5ed7970f-211a-4f6b-8938-f50938e90423	62cdd1f1-5196-45aa-afdc-0bf37b1d55d7	0	10	f	\N	\N
1ff962ff-dd63-47aa-95c2-2ac07d4db92c	\N	reset-credential-email	5ed7970f-211a-4f6b-8938-f50938e90423	62cdd1f1-5196-45aa-afdc-0bf37b1d55d7	0	20	f	\N	\N
852c2ba5-2d70-46c1-a9a8-5f35e25d4d2a	\N	reset-password	5ed7970f-211a-4f6b-8938-f50938e90423	62cdd1f1-5196-45aa-afdc-0bf37b1d55d7	0	30	f	\N	\N
a6548755-43f5-41a0-8a7b-df72db2dda0b	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	62cdd1f1-5196-45aa-afdc-0bf37b1d55d7	1	40	t	bb8b1f69-c051-48dc-90b2-227b630a605e	\N
1ed4c596-b07c-4621-95f2-81cfaa540c2e	\N	conditional-user-configured	5ed7970f-211a-4f6b-8938-f50938e90423	bb8b1f69-c051-48dc-90b2-227b630a605e	0	10	f	\N	\N
b25e47e3-60e4-4404-a934-f9de8990f4aa	\N	reset-otp	5ed7970f-211a-4f6b-8938-f50938e90423	bb8b1f69-c051-48dc-90b2-227b630a605e	0	20	f	\N	\N
7d40907a-0c76-477a-af54-8a4815693602	\N	client-secret	5ed7970f-211a-4f6b-8938-f50938e90423	50017cdf-3f44-450b-b161-6032f6e22ac7	2	10	f	\N	\N
e7ebec4d-3eda-4ace-b25c-7da0a9159f9a	\N	client-jwt	5ed7970f-211a-4f6b-8938-f50938e90423	50017cdf-3f44-450b-b161-6032f6e22ac7	2	20	f	\N	\N
8e659965-7db1-49f7-90ed-7858451b2563	\N	client-secret-jwt	5ed7970f-211a-4f6b-8938-f50938e90423	50017cdf-3f44-450b-b161-6032f6e22ac7	2	30	f	\N	\N
aa20f550-1dc5-4f31-8807-5d417e356566	\N	client-x509	5ed7970f-211a-4f6b-8938-f50938e90423	50017cdf-3f44-450b-b161-6032f6e22ac7	2	40	f	\N	\N
fc75ea84-b256-4de0-9056-ad236701c816	\N	idp-review-profile	5ed7970f-211a-4f6b-8938-f50938e90423	bd5a2851-5577-4371-80d6-5cab0bbe41a7	0	10	f	\N	48f67981-0615-4d22-ba5c-5a832eefec3f
903b8b3e-d65c-41aa-81f9-b62b6a1a39d9	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	bd5a2851-5577-4371-80d6-5cab0bbe41a7	0	20	t	0e4ae03e-feb9-43c1-916f-72be97d9b360	\N
9f97fc94-bbdd-4a8e-a909-ccd4e1d5a9f3	\N	idp-create-user-if-unique	5ed7970f-211a-4f6b-8938-f50938e90423	0e4ae03e-feb9-43c1-916f-72be97d9b360	2	10	f	\N	bea60b3d-bf0d-4650-9063-db44df3cf751
41c91f67-8896-41af-abd2-cea6be42e867	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	0e4ae03e-feb9-43c1-916f-72be97d9b360	2	20	t	5486acfe-4760-44c5-be4d-af25299d51fc	\N
35aefee4-5cc0-402d-9d1d-d4edb6d54c60	\N	idp-confirm-link	5ed7970f-211a-4f6b-8938-f50938e90423	5486acfe-4760-44c5-be4d-af25299d51fc	0	10	f	\N	\N
3924c040-eae6-4419-8bad-a3f9a06e18b8	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	5486acfe-4760-44c5-be4d-af25299d51fc	0	20	t	804ab170-3815-49b3-9316-76d82a988e40	\N
d376b4c7-8d13-4d0e-bf0f-2f4fb287ee1a	\N	idp-email-verification	5ed7970f-211a-4f6b-8938-f50938e90423	804ab170-3815-49b3-9316-76d82a988e40	2	10	f	\N	\N
e03eba16-3cfc-4daa-a0ca-d40b6f41c1ee	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	804ab170-3815-49b3-9316-76d82a988e40	2	20	t	1fcac83e-fdd0-42f3-9a7a-029c1137ded8	\N
8587df12-9d63-4e17-991c-e39908b03d68	\N	idp-username-password-form	5ed7970f-211a-4f6b-8938-f50938e90423	1fcac83e-fdd0-42f3-9a7a-029c1137ded8	0	10	f	\N	\N
0a202383-d457-46ce-9028-5e36fc1fcb97	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	1fcac83e-fdd0-42f3-9a7a-029c1137ded8	1	20	t	d124b152-c699-4aa3-bab4-c1a3a8b4249a	\N
8b0e886f-cb67-4d21-b160-29500a721d94	\N	conditional-user-configured	5ed7970f-211a-4f6b-8938-f50938e90423	d124b152-c699-4aa3-bab4-c1a3a8b4249a	0	10	f	\N	\N
97c8be8b-b271-4347-a0ea-2914202e7582	\N	auth-otp-form	5ed7970f-211a-4f6b-8938-f50938e90423	d124b152-c699-4aa3-bab4-c1a3a8b4249a	0	20	f	\N	\N
ab6eb3fe-39b0-47e2-8ec9-ffae99d2a432	\N	http-basic-authenticator	5ed7970f-211a-4f6b-8938-f50938e90423	5af12f20-a0bd-4d95-9feb-a60348e63a89	0	10	f	\N	\N
abe2f1b6-0f1e-417a-afd7-9963dbff2020	\N	docker-http-basic-authenticator	5ed7970f-211a-4f6b-8938-f50938e90423	f2d1872d-3922-473a-8a20-fed5318b2bd5	0	10	f	\N	\N
82a2a896-79ef-4d40-a0bc-e18e5e9ed207	\N	no-cookie-redirect	5ed7970f-211a-4f6b-8938-f50938e90423	32f287bb-b3f2-482e-896e-9eec85a08eeb	0	10	f	\N	\N
357758c0-d113-47ab-8021-cb54c8dbf0a5	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	32f287bb-b3f2-482e-896e-9eec85a08eeb	0	20	t	45b096c3-2d62-4ca8-8227-adea8218ba19	\N
298a179e-85fc-4b6c-9330-eb21b8f9fb18	\N	basic-auth	5ed7970f-211a-4f6b-8938-f50938e90423	45b096c3-2d62-4ca8-8227-adea8218ba19	0	10	f	\N	\N
50d65e05-a37c-4d76-91c0-0686bcca96ce	\N	basic-auth-otp	5ed7970f-211a-4f6b-8938-f50938e90423	45b096c3-2d62-4ca8-8227-adea8218ba19	3	20	f	\N	\N
5f16b7a9-07d7-485f-8583-c099504799ec	\N	auth-spnego	5ed7970f-211a-4f6b-8938-f50938e90423	45b096c3-2d62-4ca8-8227-adea8218ba19	3	30	f	\N	\N
42d055aa-02cc-469f-9658-25ee1034efb1	\N	idp-email-verification	On-premise	29232e9b-d1a0-4521-bd4c-89f7b61ebf36	2	10	f	\N	\N
f87efe7c-c143-42c6-97c9-a73a7627aa58	\N	\N	On-premise	29232e9b-d1a0-4521-bd4c-89f7b61ebf36	2	20	t	039bd240-0ba1-4609-aaab-b31663ec31e4	\N
a9741621-778f-4663-a590-93f9c601992b	\N	basic-auth	On-premise	1dc6ca18-69f0-45cc-b290-0b79982294aa	0	10	f	\N	\N
bd9ba2d9-f370-4989-8928-f14f0215105c	\N	basic-auth-otp	On-premise	1dc6ca18-69f0-45cc-b290-0b79982294aa	3	20	f	\N	\N
32c17b7d-42f0-4a92-b2ec-a1c76537c692	\N	auth-spnego	On-premise	1dc6ca18-69f0-45cc-b290-0b79982294aa	3	30	f	\N	\N
ce13e368-2f69-4230-bfaf-89b956260fdd	\N	conditional-user-configured	On-premise	9f53c4fc-2aae-4116-babb-142bd4ccd207	0	10	f	\N	\N
7b146068-8d8b-4806-ae51-24dc0ddc8be4	\N	auth-otp-form	On-premise	9f53c4fc-2aae-4116-babb-142bd4ccd207	0	20	f	\N	\N
7c5d24f9-3d7d-466b-ab33-5cda0d0f96d8	\N	conditional-user-configured	On-premise	1b7820a7-c293-4f03-8613-d0bcec941f58	0	10	f	\N	\N
52a26e53-48f8-4598-961b-636fc6e63872	\N	direct-grant-validate-otp	On-premise	1b7820a7-c293-4f03-8613-d0bcec941f58	0	20	f	\N	\N
ec16f694-4bb2-4836-ad2a-8829657c32fd	\N	conditional-user-configured	On-premise	396e0a4b-dd65-4e29-865c-dab2beee331d	0	10	f	\N	\N
3c609ec7-ec3d-48d2-9caf-3169e7427218	\N	auth-otp-form	On-premise	396e0a4b-dd65-4e29-865c-dab2beee331d	0	20	f	\N	\N
cf0f1216-3724-48ae-b3d9-690c50262b82	\N	idp-confirm-link	On-premise	5e9e6d06-4b5a-450c-9214-e822cd365520	0	10	f	\N	\N
3ca34bfb-9d8d-4370-9a69-acf0180df9ee	\N	\N	On-premise	5e9e6d06-4b5a-450c-9214-e822cd365520	0	20	t	29232e9b-d1a0-4521-bd4c-89f7b61ebf36	\N
c7a2003a-b608-45c3-811e-a5e16a2607f2	\N	conditional-user-configured	On-premise	0547152e-c24a-453a-99a7-033f2ae87582	0	10	f	\N	\N
a1871b78-dea5-426c-834a-28e6fe4645f0	\N	reset-otp	On-premise	0547152e-c24a-453a-99a7-033f2ae87582	0	20	f	\N	\N
81310568-14d3-493d-92ab-70af09593d98	\N	idp-create-user-if-unique	On-premise	67a7b2f0-2a12-413c-92a9-a29cdad6cb1d	2	10	f	\N	718f14d3-c68a-4c55-83a5-622e598d76ef
3a62bda1-b35d-4d5c-a242-2c6b9941e0c7	\N	\N	On-premise	67a7b2f0-2a12-413c-92a9-a29cdad6cb1d	2	20	t	5e9e6d06-4b5a-450c-9214-e822cd365520	\N
672b24fa-04e4-4d51-8792-fbeb2faa41a9	\N	idp-username-password-form	On-premise	039bd240-0ba1-4609-aaab-b31663ec31e4	0	10	f	\N	\N
7d3417ee-bad6-436e-b83b-7c5a7d807c79	\N	\N	On-premise	039bd240-0ba1-4609-aaab-b31663ec31e4	1	20	t	396e0a4b-dd65-4e29-865c-dab2beee331d	\N
14e78c91-9d51-44c9-b2e2-3990ef674ec4	\N	auth-cookie	On-premise	f8d52b1f-686d-46e1-b3bf-9f9fc86a7f31	2	10	f	\N	\N
8babbff7-d2fa-4d40-af03-2fea2299e62c	\N	auth-spnego	On-premise	f8d52b1f-686d-46e1-b3bf-9f9fc86a7f31	3	20	f	\N	\N
3f0b5dcd-efdd-4834-bfea-9c45093e966d	\N	identity-provider-redirector	On-premise	f8d52b1f-686d-46e1-b3bf-9f9fc86a7f31	2	25	f	\N	\N
4fa3277d-8a17-432e-98db-d52e533c6db9	\N	\N	On-premise	f8d52b1f-686d-46e1-b3bf-9f9fc86a7f31	2	30	t	bf299a96-815f-4872-8094-b53bc704c488	\N
cde7cfb1-e481-48b1-9d2f-b34dce4761d7	\N	client-secret	On-premise	ae23e0c1-c7dd-4231-b791-57ca496962db	2	10	f	\N	\N
25dde79a-4042-47fe-96ca-5d0983be2272	\N	client-jwt	On-premise	ae23e0c1-c7dd-4231-b791-57ca496962db	2	20	f	\N	\N
11aead23-8d0f-465b-a9bc-fcc31c7d7848	\N	client-secret-jwt	On-premise	ae23e0c1-c7dd-4231-b791-57ca496962db	2	30	f	\N	\N
7e8b4873-bd35-4f01-a1f1-e8872b428f7f	\N	client-x509	On-premise	ae23e0c1-c7dd-4231-b791-57ca496962db	2	40	f	\N	\N
64bc2e2d-1764-49ee-af0a-d251499075ad	\N	direct-grant-validate-username	On-premise	72337b4c-1e9c-4e26-9108-5f3f7eac44e0	0	10	f	\N	\N
25a49b55-cb51-4fb1-928b-8eca1e54f2b0	\N	direct-grant-validate-password	On-premise	72337b4c-1e9c-4e26-9108-5f3f7eac44e0	0	20	f	\N	\N
d8efdb05-edcb-49d5-8f9a-a4cc0942f0ae	\N	\N	On-premise	72337b4c-1e9c-4e26-9108-5f3f7eac44e0	1	30	t	1b7820a7-c293-4f03-8613-d0bcec941f58	\N
457b85cc-a4da-4c07-8800-ae4e23e34f15	\N	docker-http-basic-authenticator	On-premise	a5bcaf47-524d-4489-9fae-3afca40d5f66	0	10	f	\N	\N
7060ecbe-672b-48cf-b174-63ec7b7e2ce3	\N	idp-review-profile	On-premise	993c3ac4-d8c2-4878-b4e2-8cdb2cc5b7ec	0	10	f	\N	6fe4e2f5-1282-4a6b-b668-2dbb11ffe8c9
421632c0-6a69-4e4f-9075-811bcfc844eb	\N	\N	On-premise	993c3ac4-d8c2-4878-b4e2-8cdb2cc5b7ec	0	20	t	67a7b2f0-2a12-413c-92a9-a29cdad6cb1d	\N
22d78391-9705-466e-bfa7-f8903b962f38	\N	auth-username-password-form	On-premise	bf299a96-815f-4872-8094-b53bc704c488	0	10	f	\N	\N
4fa6b7ce-e7f0-47b0-a8ac-5eda9033b688	\N	\N	On-premise	bf299a96-815f-4872-8094-b53bc704c488	1	20	t	9f53c4fc-2aae-4116-babb-142bd4ccd207	\N
46894f30-cd1f-4e50-aecc-8a13cc945760	\N	no-cookie-redirect	On-premise	a4a5cc56-c4c9-4e7d-89b7-8d61a1a24cf3	0	10	f	\N	\N
79646d46-ea98-4173-b081-6c28fa9bd3b9	\N	\N	On-premise	a4a5cc56-c4c9-4e7d-89b7-8d61a1a24cf3	0	20	t	1dc6ca18-69f0-45cc-b290-0b79982294aa	\N
e31eaeca-32b3-4683-b1ca-4a3aef702068	\N	registration-page-form	On-premise	55e21239-1f6a-402f-974c-61bdbf0fa5ed	0	10	t	41380ad9-3bf1-48ec-9ac0-c348045dc1e2	\N
8e02891f-1697-4251-99ea-33b3b374c2d7	\N	registration-user-creation	On-premise	41380ad9-3bf1-48ec-9ac0-c348045dc1e2	0	20	f	\N	\N
a3c3e831-8daf-422c-9b06-0549f790c1a2	\N	registration-profile-action	On-premise	41380ad9-3bf1-48ec-9ac0-c348045dc1e2	0	40	f	\N	\N
81c35c6e-3d94-4da6-a0b2-c4df168bacc1	\N	registration-password-action	On-premise	41380ad9-3bf1-48ec-9ac0-c348045dc1e2	0	50	f	\N	\N
b1473f8b-994d-4611-9f27-27349ca7ad10	\N	registration-recaptcha-action	On-premise	41380ad9-3bf1-48ec-9ac0-c348045dc1e2	3	60	f	\N	\N
f4c7a5e1-3c85-4b88-bd2c-4c70a8a3ee9f	\N	reset-credentials-choose-user	On-premise	02ef3ef4-61ec-4afe-89cf-8f91f67faa27	0	10	f	\N	\N
6cc8d26a-8c50-4ca7-a9ee-1f0f99131410	\N	reset-credential-email	On-premise	02ef3ef4-61ec-4afe-89cf-8f91f67faa27	0	20	f	\N	\N
cb151b4a-e406-4145-a196-703875970e23	\N	reset-password	On-premise	02ef3ef4-61ec-4afe-89cf-8f91f67faa27	0	30	f	\N	\N
736596d6-5689-4728-97c4-c0b57d111bc6	\N	\N	On-premise	02ef3ef4-61ec-4afe-89cf-8f91f67faa27	1	40	t	0547152e-c24a-453a-99a7-033f2ae87582	\N
4da3e69f-6857-4ae6-8933-626e73f7d92e	\N	http-basic-authenticator	On-premise	904eb4e7-cb7f-483d-b30b-9a0fcb51e1f6	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
aaca34f0-1c81-4ecf-aae1-0ae0b8e03c2e	browser	browser based authentication	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
308cdfea-8ef1-4e1b-b8e5-51c8ad7c749d	forms	Username, password, otp and other auth forms.	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
661dbc28-2c24-4823-9358-ff7afc637f86	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
5f98c1c7-a09a-4d60-885c-b68570411531	direct grant	OpenID Connect Resource Owner Grant	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
1acf853b-d8d8-4cea-ac1e-8546b5789fa0	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
5911543b-b1eb-4a6a-82ae-5e76e78113cc	registration	registration flow	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
d86a7c98-3f78-4851-bead-9501fcde29ec	registration form	registration form	5ed7970f-211a-4f6b-8938-f50938e90423	form-flow	f	t
62cdd1f1-5196-45aa-afdc-0bf37b1d55d7	reset credentials	Reset credentials for a user if they forgot their password or something	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
bb8b1f69-c051-48dc-90b2-227b630a605e	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
50017cdf-3f44-450b-b161-6032f6e22ac7	clients	Base authentication for clients	5ed7970f-211a-4f6b-8938-f50938e90423	client-flow	t	t
bd5a2851-5577-4371-80d6-5cab0bbe41a7	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
0e4ae03e-feb9-43c1-916f-72be97d9b360	User creation or linking	Flow for the existing/non-existing user alternatives	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
5486acfe-4760-44c5-be4d-af25299d51fc	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
804ab170-3815-49b3-9316-76d82a988e40	Account verification options	Method with which to verity the existing account	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
1fcac83e-fdd0-42f3-9a7a-029c1137ded8	Verify Existing Account by Re-authentication	Reauthentication of existing account	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
d124b152-c699-4aa3-bab4-c1a3a8b4249a	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
5af12f20-a0bd-4d95-9feb-a60348e63a89	saml ecp	SAML ECP Profile Authentication Flow	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
f2d1872d-3922-473a-8a20-fed5318b2bd5	docker auth	Used by Docker clients to authenticate against the IDP	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
32f287bb-b3f2-482e-896e-9eec85a08eeb	http challenge	An authentication flow based on challenge-response HTTP Authentication Schemes	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	t	t
45b096c3-2d62-4ca8-8227-adea8218ba19	Authentication Options	Authentication options.	5ed7970f-211a-4f6b-8938-f50938e90423	basic-flow	f	t
29232e9b-d1a0-4521-bd4c-89f7b61ebf36	Account verification options	Method with which to verity the existing account	On-premise	basic-flow	f	t
1dc6ca18-69f0-45cc-b290-0b79982294aa	Authentication Options	Authentication options.	On-premise	basic-flow	f	t
9f53c4fc-2aae-4116-babb-142bd4ccd207	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	On-premise	basic-flow	f	t
1b7820a7-c293-4f03-8613-d0bcec941f58	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	On-premise	basic-flow	f	t
396e0a4b-dd65-4e29-865c-dab2beee331d	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	On-premise	basic-flow	f	t
5e9e6d06-4b5a-450c-9214-e822cd365520	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	On-premise	basic-flow	f	t
0547152e-c24a-453a-99a7-033f2ae87582	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	On-premise	basic-flow	f	t
67a7b2f0-2a12-413c-92a9-a29cdad6cb1d	User creation or linking	Flow for the existing/non-existing user alternatives	On-premise	basic-flow	f	t
039bd240-0ba1-4609-aaab-b31663ec31e4	Verify Existing Account by Re-authentication	Reauthentication of existing account	On-premise	basic-flow	f	t
f8d52b1f-686d-46e1-b3bf-9f9fc86a7f31	browser	browser based authentication	On-premise	basic-flow	t	t
ae23e0c1-c7dd-4231-b791-57ca496962db	clients	Base authentication for clients	On-premise	client-flow	t	t
72337b4c-1e9c-4e26-9108-5f3f7eac44e0	direct grant	OpenID Connect Resource Owner Grant	On-premise	basic-flow	t	t
a5bcaf47-524d-4489-9fae-3afca40d5f66	docker auth	Used by Docker clients to authenticate against the IDP	On-premise	basic-flow	t	t
993c3ac4-d8c2-4878-b4e2-8cdb2cc5b7ec	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	On-premise	basic-flow	t	t
bf299a96-815f-4872-8094-b53bc704c488	forms	Username, password, otp and other auth forms.	On-premise	basic-flow	f	t
a4a5cc56-c4c9-4e7d-89b7-8d61a1a24cf3	http challenge	An authentication flow based on challenge-response HTTP Authentication Schemes	On-premise	basic-flow	t	t
55e21239-1f6a-402f-974c-61bdbf0fa5ed	registration	registration flow	On-premise	basic-flow	t	t
41380ad9-3bf1-48ec-9ac0-c348045dc1e2	registration form	registration form	On-premise	form-flow	f	t
02ef3ef4-61ec-4afe-89cf-8f91f67faa27	reset credentials	Reset credentials for a user if they forgot their password or something	On-premise	basic-flow	t	t
904eb4e7-cb7f-483d-b30b-9a0fcb51e1f6	saml ecp	SAML ECP Profile Authentication Flow	On-premise	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
48f67981-0615-4d22-ba5c-5a832eefec3f	review profile config	5ed7970f-211a-4f6b-8938-f50938e90423
bea60b3d-bf0d-4650-9063-db44df3cf751	create unique user config	5ed7970f-211a-4f6b-8938-f50938e90423
718f14d3-c68a-4c55-83a5-622e598d76ef	create unique user config	On-premise
6fe4e2f5-1282-4a6b-b668-2dbb11ffe8c9	review profile config	On-premise
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
48f67981-0615-4d22-ba5c-5a832eefec3f	missing	update.profile.on.first.login
bea60b3d-bf0d-4650-9063-db44df3cf751	false	require.password.update.after.registration
6fe4e2f5-1282-4a6b-b668-2dbb11ffe8c9	missing	update.profile.on.first.login
718f14d3-c68a-4c55-83a5-622e598d76ef	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
64b186bc-71c6-464e-9796-0387b69e11a3	t	f	master-realm	0	f	\N	\N	t	\N	f	5ed7970f-211a-4f6b-8938-f50938e90423	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	5ed7970f-211a-4f6b-8938-f50938e90423	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
138412d0-f1d5-4a20-90b3-b5ce26d89b93	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	5ed7970f-211a-4f6b-8938-f50938e90423	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
f653a789-b4d1-42a6-8265-063cf05d6594	t	f	broker	0	f	\N	\N	t	\N	f	5ed7970f-211a-4f6b-8938-f50938e90423	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
ca64abba-762f-4ffb-9423-6a53838c84a8	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	5ed7970f-211a-4f6b-8938-f50938e90423	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
d2805495-b08b-493c-8f32-b537f2b1a119	t	f	admin-cli	0	t	\N	\N	f	\N	f	5ed7970f-211a-4f6b-8938-f50938e90423	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	f	On-premise-realm	0	f	\N	\N	t	\N	f	5ed7970f-211a-4f6b-8938-f50938e90423	\N	0	f	f	On-premise Realm	f	client-secret	\N	\N	\N	t	f	f	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	f	account	0	t	\N	/realms/On-premise/account/	f	\N	f	On-premise	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
63e63428-fdea-4672-8e4f-d7a4df56393f	t	f	account-console	0	t	\N	/realms/On-premise/account/	f	\N	f	On-premise	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	t	f	admin-cli	0	t	\N	\N	f	\N	f	On-premise	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	t	t	avni-client	0	t	\N		f		f	On-premise	openid-connect	-1	f	f		t	client-secret	https://3.109.55.3:8022		\N	t	f	t	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	t	f	broker	0	f	\N	\N	t	\N	f	On-premise	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
818e3596-2ff1-4056-9230-704e8fac0ca1	t	f	realm-management	0	f	\N	\N	t	\N	f	On-premise	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
f355103f-48b5-4615-adb5-9992c317295c	t	f	security-admin-console	0	t	\N	/admin/On-premise/console/	f	\N	f	On-premise	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
4381c433-5988-418a-bc71-177bb46e873a	t	t	admin-api	0	f	kuI0hFhPoprbZedHsiFTmbhPzGpjGCZj	\N	f	http://localhost:8080	f	On-premise	openid-connect	-1	f	f	\N	t	client-secret	http://localhost:8080	\N	\N	t	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	post.logout.redirect.uris	+
138412d0-f1d5-4a20-90b3-b5ce26d89b93	post.logout.redirect.uris	+
138412d0-f1d5-4a20-90b3-b5ce26d89b93	pkce.code.challenge.method	S256
ca64abba-762f-4ffb-9423-6a53838c84a8	post.logout.redirect.uris	+
ca64abba-762f-4ffb-9423-6a53838c84a8	pkce.code.challenge.method	S256
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	post.logout.redirect.uris	+
63e63428-fdea-4672-8e4f-d7a4df56393f	post.logout.redirect.uris	+
63e63428-fdea-4672-8e4f-d7a4df56393f	pkce.code.challenge.method	S256
4381c433-5988-418a-bc71-177bb46e873a	saml.multivalued.roles	false
4381c433-5988-418a-bc71-177bb46e873a	saml.force.post.binding	false
4381c433-5988-418a-bc71-177bb46e873a	frontchannel.logout.session.required	false
4381c433-5988-418a-bc71-177bb46e873a	post.logout.redirect.uris	+
4381c433-5988-418a-bc71-177bb46e873a	oauth2.device.authorization.grant.enabled	false
4381c433-5988-418a-bc71-177bb46e873a	backchannel.logout.revoke.offline.tokens	false
4381c433-5988-418a-bc71-177bb46e873a	saml.server.signature.keyinfo.ext	false
4381c433-5988-418a-bc71-177bb46e873a	use.refresh.tokens	true
4381c433-5988-418a-bc71-177bb46e873a	oidc.ciba.grant.enabled	false
4381c433-5988-418a-bc71-177bb46e873a	backchannel.logout.session.required	true
4381c433-5988-418a-bc71-177bb46e873a	client_credentials.use_refresh_token	false
4381c433-5988-418a-bc71-177bb46e873a	saml.client.signature	false
4381c433-5988-418a-bc71-177bb46e873a	require.pushed.authorization.requests	false
4381c433-5988-418a-bc71-177bb46e873a	saml.allow.ecp.flow	false
4381c433-5988-418a-bc71-177bb46e873a	saml.assertion.signature	false
4381c433-5988-418a-bc71-177bb46e873a	id.token.as.detached.signature	false
4381c433-5988-418a-bc71-177bb46e873a	saml.encrypt	false
4381c433-5988-418a-bc71-177bb46e873a	saml.server.signature	false
4381c433-5988-418a-bc71-177bb46e873a	exclude.session.state.from.auth.response	false
4381c433-5988-418a-bc71-177bb46e873a	saml.artifact.binding	false
4381c433-5988-418a-bc71-177bb46e873a	saml_force_name_id_format	false
4381c433-5988-418a-bc71-177bb46e873a	tls.client.certificate.bound.access.tokens	false
4381c433-5988-418a-bc71-177bb46e873a	acr.loa.map	{}
4381c433-5988-418a-bc71-177bb46e873a	saml.authnstatement	false
4381c433-5988-418a-bc71-177bb46e873a	display.on.consent.screen	false
4381c433-5988-418a-bc71-177bb46e873a	token.response.type.bearer.lower-case	false
4381c433-5988-418a-bc71-177bb46e873a	saml.onetimeuse.condition	false
4ee575c8-6afb-4a08-bdba-2f771515c63b	post.logout.redirect.uris	+
915277c7-706e-4aa8-ad41-dfc2c3818c0b	access.token.lifespan	600
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.force.post.binding	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.multivalued.roles	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	frontchannel.logout.session.required	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	post.logout.redirect.uris	+
915277c7-706e-4aa8-ad41-dfc2c3818c0b	oauth2.device.authorization.grant.enabled	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	backchannel.logout.revoke.offline.tokens	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.server.signature.keyinfo.ext	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	use.refresh.tokens	true
915277c7-706e-4aa8-ad41-dfc2c3818c0b	oidc.ciba.grant.enabled	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	backchannel.logout.session.required	true
915277c7-706e-4aa8-ad41-dfc2c3818c0b	client_credentials.use_refresh_token	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	require.pushed.authorization.requests	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.client.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.allow.ecp.flow	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	id.token.as.detached.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.assertion.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	client.secret.creation.time	1656653576
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.encrypt	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.server.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	exclude.session.state.from.auth.response	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	tls-client-certificate-bound-access-tokens	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.artifact.binding	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml_force_name_id_format	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	acr.loa.map	{}
915277c7-706e-4aa8-ad41-dfc2c3818c0b	tls.client.certificate.bound.access.tokens	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.authnstatement	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	display.on.consent.screen	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	token.response.type.bearer.lower-case	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.onetimeuse.condition	false
82b820b4-c7f1-4946-8e97-7cda75eca5a3	post.logout.redirect.uris	+
818e3596-2ff1-4056-9230-704e8fac0ca1	post.logout.redirect.uris	+
f355103f-48b5-4615-adb5-9992c317295c	post.logout.redirect.uris	+
f355103f-48b5-4615-adb5-9992c317295c	pkce.code.challenge.method	S256
4381c433-5988-418a-bc71-177bb46e873a	client.secret.creation.time	1685432472
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
915277c7-706e-4aa8-ad41-dfc2c3818c0b	f8d52b1f-686d-46e1-b3bf-9f9fc86a7f31	browser
915277c7-706e-4aa8-ad41-dfc2c3818c0b	72337b4c-1e9c-4e26-9108-5f3f7eac44e0	direct_grant
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
8a85ca55-eb51-410e-b234-71260cbc1731	offline_access	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect built-in scope: offline_access	openid-connect
46c7c663-c060-44e9-be16-85663441d262	role_list	5ed7970f-211a-4f6b-8938-f50938e90423	SAML role list	saml
971c4ebb-6c43-4748-94b6-a10e7421c561	profile	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect built-in scope: profile	openid-connect
5d755794-7705-45a2-9344-55b27bd7b857	email	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect built-in scope: email	openid-connect
b555b4f6-4df9-4f43-bb30-556b88592c74	address	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect built-in scope: address	openid-connect
d4d29ad6-8d91-4f6b-b229-e1cc470ae519	phone	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect built-in scope: phone	openid-connect
5eee0da0-11f3-4ba2-8cc1-e3dec677c683	roles	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect scope for add user roles to the access token	openid-connect
c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	web-origins	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect scope for add allowed web origins to the access token	openid-connect
f32fff6f-7966-4f0f-9d25-52e8979295f0	microprofile-jwt	5ed7970f-211a-4f6b-8938-f50938e90423	Microprofile - JWT built-in scope	openid-connect
98585029-d919-48c4-8b71-03a8c293427e	acr	5ed7970f-211a-4f6b-8938-f50938e90423	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	phone	On-premise	OpenID Connect built-in scope: phone	openid-connect
fb5fb072-87e0-490e-9dba-3bfaa677b35e	email	On-premise	OpenID Connect built-in scope: email	openid-connect
b97a5f52-b8bf-4313-a458-d5af0b16c629	microprofile-jwt	On-premise	Microprofile - JWT built-in scope	openid-connect
ac87c569-2002-45ff-b330-b4fc5303051e	offline_access	On-premise	OpenID Connect built-in scope: offline_access	openid-connect
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	web-origins	On-premise	OpenID Connect scope for add allowed web origins to the access token	openid-connect
9db74845-4196-4859-82b4-dd4ac268d672	acr	On-premise	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	roles	On-premise	OpenID Connect scope for add user roles to the access token	openid-connect
445e57d8-6cb8-49a7-a566-480c1b754409	role_list	On-premise	SAML role list	saml
c32f274c-e449-4afe-bb2f-8cd75d24207d	address	On-premise	OpenID Connect built-in scope: address	openid-connect
fa931807-b3af-4ae0-81b7-267055627626	avni-server	On-premise	\N	openid-connect
ae2a301a-d22f-46e6-a736-5e3837e6b18a	profile	On-premise	OpenID Connect built-in scope: profile	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
8a85ca55-eb51-410e-b234-71260cbc1731	true	display.on.consent.screen
8a85ca55-eb51-410e-b234-71260cbc1731	${offlineAccessScopeConsentText}	consent.screen.text
46c7c663-c060-44e9-be16-85663441d262	true	display.on.consent.screen
46c7c663-c060-44e9-be16-85663441d262	${samlRoleListScopeConsentText}	consent.screen.text
971c4ebb-6c43-4748-94b6-a10e7421c561	true	display.on.consent.screen
971c4ebb-6c43-4748-94b6-a10e7421c561	${profileScopeConsentText}	consent.screen.text
971c4ebb-6c43-4748-94b6-a10e7421c561	true	include.in.token.scope
5d755794-7705-45a2-9344-55b27bd7b857	true	display.on.consent.screen
5d755794-7705-45a2-9344-55b27bd7b857	${emailScopeConsentText}	consent.screen.text
5d755794-7705-45a2-9344-55b27bd7b857	true	include.in.token.scope
b555b4f6-4df9-4f43-bb30-556b88592c74	true	display.on.consent.screen
b555b4f6-4df9-4f43-bb30-556b88592c74	${addressScopeConsentText}	consent.screen.text
b555b4f6-4df9-4f43-bb30-556b88592c74	true	include.in.token.scope
d4d29ad6-8d91-4f6b-b229-e1cc470ae519	true	display.on.consent.screen
d4d29ad6-8d91-4f6b-b229-e1cc470ae519	${phoneScopeConsentText}	consent.screen.text
d4d29ad6-8d91-4f6b-b229-e1cc470ae519	true	include.in.token.scope
5eee0da0-11f3-4ba2-8cc1-e3dec677c683	true	display.on.consent.screen
5eee0da0-11f3-4ba2-8cc1-e3dec677c683	${rolesScopeConsentText}	consent.screen.text
5eee0da0-11f3-4ba2-8cc1-e3dec677c683	false	include.in.token.scope
c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	false	display.on.consent.screen
c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd		consent.screen.text
c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	false	include.in.token.scope
f32fff6f-7966-4f0f-9d25-52e8979295f0	false	display.on.consent.screen
f32fff6f-7966-4f0f-9d25-52e8979295f0	true	include.in.token.scope
98585029-d919-48c4-8b71-03a8c293427e	false	display.on.consent.screen
98585029-d919-48c4-8b71-03a8c293427e	false	include.in.token.scope
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	true	include.in.token.scope
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	true	display.on.consent.screen
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	${phoneScopeConsentText}	consent.screen.text
fb5fb072-87e0-490e-9dba-3bfaa677b35e	true	include.in.token.scope
fb5fb072-87e0-490e-9dba-3bfaa677b35e	true	display.on.consent.screen
fb5fb072-87e0-490e-9dba-3bfaa677b35e	${emailScopeConsentText}	consent.screen.text
b97a5f52-b8bf-4313-a458-d5af0b16c629	true	include.in.token.scope
b97a5f52-b8bf-4313-a458-d5af0b16c629	false	display.on.consent.screen
ac87c569-2002-45ff-b330-b4fc5303051e	${offlineAccessScopeConsentText}	consent.screen.text
ac87c569-2002-45ff-b330-b4fc5303051e	true	display.on.consent.screen
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	false	include.in.token.scope
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	false	display.on.consent.screen
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442		consent.screen.text
9db74845-4196-4859-82b4-dd4ac268d672	false	include.in.token.scope
9db74845-4196-4859-82b4-dd4ac268d672	false	display.on.consent.screen
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	false	include.in.token.scope
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	true	display.on.consent.screen
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	${rolesScopeConsentText}	consent.screen.text
445e57d8-6cb8-49a7-a566-480c1b754409	${samlRoleListScopeConsentText}	consent.screen.text
445e57d8-6cb8-49a7-a566-480c1b754409	true	display.on.consent.screen
c32f274c-e449-4afe-bb2f-8cd75d24207d	true	include.in.token.scope
c32f274c-e449-4afe-bb2f-8cd75d24207d	true	display.on.consent.screen
c32f274c-e449-4afe-bb2f-8cd75d24207d	${addressScopeConsentText}	consent.screen.text
fa931807-b3af-4ae0-81b7-267055627626	true	include.in.token.scope
fa931807-b3af-4ae0-81b7-267055627626	true	display.on.consent.screen
ae2a301a-d22f-46e6-a736-5e3837e6b18a	true	include.in.token.scope
ae2a301a-d22f-46e6-a736-5e3837e6b18a	true	display.on.consent.screen
ae2a301a-d22f-46e6-a736-5e3837e6b18a	${profileScopeConsentText}	consent.screen.text
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	t
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	971c4ebb-6c43-4748-94b6-a10e7421c561	t
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	5d755794-7705-45a2-9344-55b27bd7b857	t
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	5eee0da0-11f3-4ba2-8cc1-e3dec677c683	t
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	98585029-d919-48c4-8b71-03a8c293427e	t
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	b555b4f6-4df9-4f43-bb30-556b88592c74	f
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	f32fff6f-7966-4f0f-9d25-52e8979295f0	f
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	d4d29ad6-8d91-4f6b-b229-e1cc470ae519	f
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	8a85ca55-eb51-410e-b234-71260cbc1731	f
138412d0-f1d5-4a20-90b3-b5ce26d89b93	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	t
138412d0-f1d5-4a20-90b3-b5ce26d89b93	971c4ebb-6c43-4748-94b6-a10e7421c561	t
138412d0-f1d5-4a20-90b3-b5ce26d89b93	5d755794-7705-45a2-9344-55b27bd7b857	t
138412d0-f1d5-4a20-90b3-b5ce26d89b93	5eee0da0-11f3-4ba2-8cc1-e3dec677c683	t
138412d0-f1d5-4a20-90b3-b5ce26d89b93	98585029-d919-48c4-8b71-03a8c293427e	t
138412d0-f1d5-4a20-90b3-b5ce26d89b93	b555b4f6-4df9-4f43-bb30-556b88592c74	f
138412d0-f1d5-4a20-90b3-b5ce26d89b93	f32fff6f-7966-4f0f-9d25-52e8979295f0	f
138412d0-f1d5-4a20-90b3-b5ce26d89b93	d4d29ad6-8d91-4f6b-b229-e1cc470ae519	f
138412d0-f1d5-4a20-90b3-b5ce26d89b93	8a85ca55-eb51-410e-b234-71260cbc1731	f
d2805495-b08b-493c-8f32-b537f2b1a119	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	t
d2805495-b08b-493c-8f32-b537f2b1a119	971c4ebb-6c43-4748-94b6-a10e7421c561	t
d2805495-b08b-493c-8f32-b537f2b1a119	5d755794-7705-45a2-9344-55b27bd7b857	t
d2805495-b08b-493c-8f32-b537f2b1a119	5eee0da0-11f3-4ba2-8cc1-e3dec677c683	t
d2805495-b08b-493c-8f32-b537f2b1a119	98585029-d919-48c4-8b71-03a8c293427e	t
d2805495-b08b-493c-8f32-b537f2b1a119	b555b4f6-4df9-4f43-bb30-556b88592c74	f
d2805495-b08b-493c-8f32-b537f2b1a119	f32fff6f-7966-4f0f-9d25-52e8979295f0	f
d2805495-b08b-493c-8f32-b537f2b1a119	d4d29ad6-8d91-4f6b-b229-e1cc470ae519	f
d2805495-b08b-493c-8f32-b537f2b1a119	8a85ca55-eb51-410e-b234-71260cbc1731	f
f653a789-b4d1-42a6-8265-063cf05d6594	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	t
f653a789-b4d1-42a6-8265-063cf05d6594	971c4ebb-6c43-4748-94b6-a10e7421c561	t
f653a789-b4d1-42a6-8265-063cf05d6594	5d755794-7705-45a2-9344-55b27bd7b857	t
f653a789-b4d1-42a6-8265-063cf05d6594	5eee0da0-11f3-4ba2-8cc1-e3dec677c683	t
f653a789-b4d1-42a6-8265-063cf05d6594	98585029-d919-48c4-8b71-03a8c293427e	t
f653a789-b4d1-42a6-8265-063cf05d6594	b555b4f6-4df9-4f43-bb30-556b88592c74	f
f653a789-b4d1-42a6-8265-063cf05d6594	f32fff6f-7966-4f0f-9d25-52e8979295f0	f
f653a789-b4d1-42a6-8265-063cf05d6594	d4d29ad6-8d91-4f6b-b229-e1cc470ae519	f
f653a789-b4d1-42a6-8265-063cf05d6594	8a85ca55-eb51-410e-b234-71260cbc1731	f
64b186bc-71c6-464e-9796-0387b69e11a3	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	t
64b186bc-71c6-464e-9796-0387b69e11a3	971c4ebb-6c43-4748-94b6-a10e7421c561	t
64b186bc-71c6-464e-9796-0387b69e11a3	5d755794-7705-45a2-9344-55b27bd7b857	t
64b186bc-71c6-464e-9796-0387b69e11a3	5eee0da0-11f3-4ba2-8cc1-e3dec677c683	t
64b186bc-71c6-464e-9796-0387b69e11a3	98585029-d919-48c4-8b71-03a8c293427e	t
64b186bc-71c6-464e-9796-0387b69e11a3	b555b4f6-4df9-4f43-bb30-556b88592c74	f
64b186bc-71c6-464e-9796-0387b69e11a3	f32fff6f-7966-4f0f-9d25-52e8979295f0	f
64b186bc-71c6-464e-9796-0387b69e11a3	d4d29ad6-8d91-4f6b-b229-e1cc470ae519	f
64b186bc-71c6-464e-9796-0387b69e11a3	8a85ca55-eb51-410e-b234-71260cbc1731	f
ca64abba-762f-4ffb-9423-6a53838c84a8	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	t
ca64abba-762f-4ffb-9423-6a53838c84a8	971c4ebb-6c43-4748-94b6-a10e7421c561	t
ca64abba-762f-4ffb-9423-6a53838c84a8	5d755794-7705-45a2-9344-55b27bd7b857	t
ca64abba-762f-4ffb-9423-6a53838c84a8	5eee0da0-11f3-4ba2-8cc1-e3dec677c683	t
ca64abba-762f-4ffb-9423-6a53838c84a8	98585029-d919-48c4-8b71-03a8c293427e	t
ca64abba-762f-4ffb-9423-6a53838c84a8	b555b4f6-4df9-4f43-bb30-556b88592c74	f
ca64abba-762f-4ffb-9423-6a53838c84a8	f32fff6f-7966-4f0f-9d25-52e8979295f0	f
ca64abba-762f-4ffb-9423-6a53838c84a8	d4d29ad6-8d91-4f6b-b229-e1cc470ae519	f
ca64abba-762f-4ffb-9423-6a53838c84a8	8a85ca55-eb51-410e-b234-71260cbc1731	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	9db74845-4196-4859-82b4-dd4ac268d672	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	ac87c569-2002-45ff-b330-b4fc5303051e	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
63e63428-fdea-4672-8e4f-d7a4df56393f	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
63e63428-fdea-4672-8e4f-d7a4df56393f	9db74845-4196-4859-82b4-dd4ac268d672	t
63e63428-fdea-4672-8e4f-d7a4df56393f	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
63e63428-fdea-4672-8e4f-d7a4df56393f	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
63e63428-fdea-4672-8e4f-d7a4df56393f	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
63e63428-fdea-4672-8e4f-d7a4df56393f	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
63e63428-fdea-4672-8e4f-d7a4df56393f	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
63e63428-fdea-4672-8e4f-d7a4df56393f	ac87c569-2002-45ff-b330-b4fc5303051e	f
63e63428-fdea-4672-8e4f-d7a4df56393f	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
4381c433-5988-418a-bc71-177bb46e873a	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
4381c433-5988-418a-bc71-177bb46e873a	9db74845-4196-4859-82b4-dd4ac268d672	t
4381c433-5988-418a-bc71-177bb46e873a	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
4381c433-5988-418a-bc71-177bb46e873a	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
4381c433-5988-418a-bc71-177bb46e873a	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
4381c433-5988-418a-bc71-177bb46e873a	fa931807-b3af-4ae0-81b7-267055627626	t
4381c433-5988-418a-bc71-177bb46e873a	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
4381c433-5988-418a-bc71-177bb46e873a	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
4381c433-5988-418a-bc71-177bb46e873a	ac87c569-2002-45ff-b330-b4fc5303051e	f
4381c433-5988-418a-bc71-177bb46e873a	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	9db74845-4196-4859-82b4-dd4ac268d672	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	ac87c569-2002-45ff-b330-b4fc5303051e	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	9db74845-4196-4859-82b4-dd4ac268d672	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	fa931807-b3af-4ae0-81b7-267055627626	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	ac87c569-2002-45ff-b330-b4fc5303051e	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	9db74845-4196-4859-82b4-dd4ac268d672	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	ac87c569-2002-45ff-b330-b4fc5303051e	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
818e3596-2ff1-4056-9230-704e8fac0ca1	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
818e3596-2ff1-4056-9230-704e8fac0ca1	9db74845-4196-4859-82b4-dd4ac268d672	t
818e3596-2ff1-4056-9230-704e8fac0ca1	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
818e3596-2ff1-4056-9230-704e8fac0ca1	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
818e3596-2ff1-4056-9230-704e8fac0ca1	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
818e3596-2ff1-4056-9230-704e8fac0ca1	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
818e3596-2ff1-4056-9230-704e8fac0ca1	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
818e3596-2ff1-4056-9230-704e8fac0ca1	ac87c569-2002-45ff-b330-b4fc5303051e	f
818e3596-2ff1-4056-9230-704e8fac0ca1	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
f355103f-48b5-4615-adb5-9992c317295c	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
f355103f-48b5-4615-adb5-9992c317295c	9db74845-4196-4859-82b4-dd4ac268d672	t
f355103f-48b5-4615-adb5-9992c317295c	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
f355103f-48b5-4615-adb5-9992c317295c	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
f355103f-48b5-4615-adb5-9992c317295c	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
f355103f-48b5-4615-adb5-9992c317295c	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
f355103f-48b5-4615-adb5-9992c317295c	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
f355103f-48b5-4615-adb5-9992c317295c	ac87c569-2002-45ff-b330-b4fc5303051e	f
f355103f-48b5-4615-adb5-9992c317295c	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
8a85ca55-eb51-410e-b234-71260cbc1731	0630deed-a301-45b5-a8fb-303f888dc074
ac87c569-2002-45ff-b330-b4fc5303051e	3ee7ccc9-1bc8-4218-b4fd-834c267f876b
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
4a1a5d85-7347-424c-8857-b508fafba7cb	Trusted Hosts	5ed7970f-211a-4f6b-8938-f50938e90423	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	anonymous
4f4d247c-3855-492e-8d4b-14f43fef09c2	Consent Required	5ed7970f-211a-4f6b-8938-f50938e90423	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	anonymous
6f51bece-8be7-4d4e-bbf8-80ed22a0b2fa	Full Scope Disabled	5ed7970f-211a-4f6b-8938-f50938e90423	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	anonymous
f80c361c-5781-4d35-b95d-6bfda4e21e38	Max Clients Limit	5ed7970f-211a-4f6b-8938-f50938e90423	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	anonymous
562818b5-4073-475c-ab51-c2e1e40fdc31	Allowed Protocol Mapper Types	5ed7970f-211a-4f6b-8938-f50938e90423	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	anonymous
63ae7acf-36a1-46ba-92b2-a596cd89ce7e	Allowed Client Scopes	5ed7970f-211a-4f6b-8938-f50938e90423	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	anonymous
5b7fea61-a46d-4c46-8ade-ef46ce2290b2	Allowed Protocol Mapper Types	5ed7970f-211a-4f6b-8938-f50938e90423	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	authenticated
29d862e6-bb9e-4c30-a69d-870771fe1eb7	Allowed Client Scopes	5ed7970f-211a-4f6b-8938-f50938e90423	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	authenticated
fdbfd01b-1067-4e87-9d52-914f889f585f	rsa-generated	5ed7970f-211a-4f6b-8938-f50938e90423	rsa-generated	org.keycloak.keys.KeyProvider	5ed7970f-211a-4f6b-8938-f50938e90423	\N
deaa88e6-f267-4973-98c0-b5f74116c535	rsa-enc-generated	5ed7970f-211a-4f6b-8938-f50938e90423	rsa-enc-generated	org.keycloak.keys.KeyProvider	5ed7970f-211a-4f6b-8938-f50938e90423	\N
8e4e2079-0b81-4237-a7f5-15be6ba17160	hmac-generated	5ed7970f-211a-4f6b-8938-f50938e90423	hmac-generated	org.keycloak.keys.KeyProvider	5ed7970f-211a-4f6b-8938-f50938e90423	\N
94bc69e8-63d9-40d7-a40c-420e7a2b0106	aes-generated	5ed7970f-211a-4f6b-8938-f50938e90423	aes-generated	org.keycloak.keys.KeyProvider	5ed7970f-211a-4f6b-8938-f50938e90423	\N
94c15efc-8ace-4893-9b56-802a93222086	Full Scope Disabled	On-premise	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
3fd3805c-e371-449c-adb6-bd7375a11a42	Max Clients Limit	On-premise	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
52b4d82e-484c-411c-9644-c1ca8bd4e513	Trusted Hosts	On-premise	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
98959d63-700b-40c1-98cd-18edf25df8fe	Allowed Protocol Mapper Types	On-premise	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	authenticated
7f041d01-ebee-44b9-a17c-2f8e256d00e7	Consent Required	On-premise	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
a99c7d98-7312-4c31-8db7-3aad3254e805	Allowed Client Scopes	On-premise	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
052e3758-7f2b-4c65-ad0e-9430d29769e6	Allowed Protocol Mapper Types	On-premise	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
e34baa09-e3fc-4251-9b60-9928b2f4520d	Allowed Client Scopes	On-premise	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	authenticated
93651be0-058b-4c0c-86ff-113e7d4d33cd	\N	On-premise	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	On-premise	\N
d56cdec7-6a5f-40ad-800f-ab5092ac1c00	hmac-generated	On-premise	hmac-generated	org.keycloak.keys.KeyProvider	On-premise	\N
93bc66e1-e7e8-4915-a30b-189312230aa6	rsa-generated	On-premise	rsa-generated	org.keycloak.keys.KeyProvider	On-premise	\N
2a4271b6-e4ce-45d7-ad60-def6e56a51aa	aes-generated	On-premise	aes-generated	org.keycloak.keys.KeyProvider	On-premise	\N
b84452da-cbd1-4077-bd02-b1130551ac9f	rsa-enc-generated	On-premise	rsa-enc-generated	org.keycloak.keys.KeyProvider	On-premise	\N
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
97bc2016-6bac-4582-855d-5cea46e1adbb	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
88788c4d-caf7-4a12-a0a3-3a39ead60444	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
8bac36a7-df5d-4929-a5e1-1e3b575216be	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	oidc-full-name-mapper
cdea6264-fc5c-4cb6-b8c2-0476008730d0	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	saml-user-property-mapper
f7cd0678-1426-4c2c-a8ee-42a349ba2439	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
f1f56dcd-2843-414b-879b-648bdbd18f20	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	saml-user-attribute-mapper
7d1a2563-9311-4902-84ec-e750800e0b35	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	oidc-address-mapper
58fe565f-2d05-4fc6-83c2-110112004855	562818b5-4073-475c-ab51-c2e1e40fdc31	allowed-protocol-mapper-types	saml-role-list-mapper
9e001466-19aa-4dde-bb94-0096ef28ea14	f80c361c-5781-4d35-b95d-6bfda4e21e38	max-clients	200
9978044a-fdbb-45f9-a117-8a7d5ecdbec0	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
ec0ab5a8-1b2d-44c1-b554-33296f404810	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	saml-role-list-mapper
af5ffa12-18a0-4680-8a6c-840597a58ab3	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	oidc-address-mapper
7eca842b-4689-4acb-b68a-d19a56580389	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	oidc-full-name-mapper
e658357a-2414-480d-8458-6a548b966cd6	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
27b447d6-fb18-4eb1-9695-301eecc13d1a	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	saml-user-property-mapper
437cb357-ab35-4b8d-9ec9-f405e09a4c2c	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
7cd194fc-cc86-4b20-9620-b6a2c352c5d5	5b7fea61-a46d-4c46-8ade-ef46ce2290b2	allowed-protocol-mapper-types	saml-user-attribute-mapper
5b27ace8-a389-439d-bced-21a7429983d7	4a1a5d85-7347-424c-8857-b508fafba7cb	client-uris-must-match	true
98431d2c-4aed-4db4-b198-6421abcaf608	4a1a5d85-7347-424c-8857-b508fafba7cb	host-sending-registration-request-must-match	true
0f2dc746-e548-4454-b8ae-f04e5028c447	63ae7acf-36a1-46ba-92b2-a596cd89ce7e	allow-default-scopes	true
49d49848-e2e0-46f1-87da-d6b6a8c4fed2	29d862e6-bb9e-4c30-a69d-870771fe1eb7	allow-default-scopes	true
61588776-8dab-412b-95c5-e76b42db5188	fdbfd01b-1067-4e87-9d52-914f889f585f	keyUse	SIG
ceda19f4-7b51-42a4-b60a-a1191cf250a0	fdbfd01b-1067-4e87-9d52-914f889f585f	privateKey	MIIEowIBAAKCAQEAn6naZxOB4Gcz2qnCte8qWbGCTZFEg9drsH3SGRsi58X+VW+GTyM+MQgsQbLrKo2i9l1TIMfHLyvj4VSWSRTCoFzNurQ/ZwcHQhq7+tNtfd3MEHMMznwJc3rBycHXLaZEMdoI2Zp71VVBx4V1btLbKTsc7EyXWzZd8Y+LGcCUeG8SnbZauqlJOdBQqUrcqNnSLmWt8pje7V99156KWcIDMcIWtizISQ9FXF2FrEwqUv4OsJpRX7AXydhphpWmf6q+iNhdFGTTMxwxptvi0yHm4HUpfaEB3hpMnm+gGmb1euNgvoxtvuT6pl4S5POV1HgMJxiMVz7Yp+J0iCz9NoBgxQIDAQABAoIBABglGMbdM5cSrEwNP4mBV0N0nVqrFPQmI94vDNJooOTxc2aKpMI7d2h1TrIJw1fuTt5YWx2aMJRA3CeDge2f0tXq6t6o6uyi6rVTsyk5h3WREM7NAzsHlWtN/VfMNUTtP6NVUGDN5JuslrO8Sje98dAgpR1T8NClnlvNJBE7Jwi2L9aPxE86s1JX8GYu+tO6gsKFsPcWFL5k1s3r3D33JngZWxC5SABjGTPEGibVIeoMIIAwv0IzxhurlvWLYCPFomH9aRrtYS8kqYvuCwkoM/859xooOXobnS4if3FcZW1kJXUpODzSnxW9ujeyPlJDxrpsU9P4t2gW6TjXdAGSNdECgYEA4TwjNu8ZPy7E6dcY8sGlMNSPqEGTwS7fPWaaAUNzJiSe6yg8PAxIjZSSqv3keOVGy2S851sQp83vizVNt9Z+e08RZwj3CJu7lh5lujGpomznhPWCCnZ5dTcBGzc9tGtxURT1dYp8Cos/HkprEd0KHbHg2p85cLVNMo523jl9jLECgYEAtXjbuHMz3JSL8o+lTgyZd27+FEqevcIuAI5K2TR+a1AiJuwaNOZnHeRds/TesCA+GNeVE7gzyyeDT/Sa9AyUwzMrf2B7lqVAmT6itFEurBXXUNm8rYIJpDHs9SM5nD9kPulXY+q+r0z45S9OJPzHwDqemmEyc4FcDe1E/LrdylUCgYAJJSz03Q50X0zFheNQcAZqDidrGIaMUH/l+VWFeZyiTthZCgAwG/uSLBcsdDSjqAOQ3J1C85KgjZ8NUvO95CqsjRBS061cHx6lwMQ2pC+UFcHsxx8pl5fk53/XAA40Vix6s1QoGqBguTit3S2twwDXJdLQbaiiZ+ojhF9VNJZhcQKBgQClfJVB2yyMFpqYlA324t6AX6Mr9fBUs2Mn9pqjAI/YZLcAL4amfwXB6KLanI8GpiB6nv2/gdcZh+rjWviDXYW7jEo6Wk3ZztDd7pSJQw8AttonTKgWweLw7OZdlcXPiq9r/3ZGE6fYTKUcusrUSAAQeGRx+/j6BBliSeEDZ5UiEQKBgHKt9kjIijkmQmsM+oOk4YhE9DVBldPOwH2nGv/XoPIBvCFJlYLwYoCDC3Ulxwaa+iW3KxxSEKjop41Bpba27LgIqLGSKQfMsl95rDnYEaOBzJUcCKDk7KvDSBLjxBnEPJB27+0WPorCT4+y/6p50aLpkfHJAmCn2+ljR/8pScKt
480e7795-d094-49f2-8a82-e8b84b38555f	fdbfd01b-1067-4e87-9d52-914f889f585f	priority	100
54180a22-c6e0-48b1-8cff-77caf0f3ca93	fdbfd01b-1067-4e87-9d52-914f889f585f	certificate	MIICmzCCAYMCBgGIa5kyVzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjMwNTMwMDczODAyWhcNMzMwNTMwMDczOTQyWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCfqdpnE4HgZzPaqcK17ypZsYJNkUSD12uwfdIZGyLnxf5Vb4ZPIz4xCCxBsusqjaL2XVMgx8cvK+PhVJZJFMKgXM26tD9nBwdCGrv602193cwQcwzOfAlzesHJwdctpkQx2gjZmnvVVUHHhXVu0tspOxzsTJdbNl3xj4sZwJR4bxKdtlq6qUk50FCpStyo2dIuZa3ymN7tX33XnopZwgMxwha2LMhJD0VcXYWsTCpS/g6wmlFfsBfJ2GmGlaZ/qr6I2F0UZNMzHDGm2+LTIebgdSl9oQHeGkyeb6AaZvV642C+jG2+5PqmXhLk85XUeAwnGIxXPtin4nSILP02gGDFAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAH53jj8Y0T5prCRLKBJ1m5IhUkK5bY6weR7e/25wF2m+A7fyZW1MsFkhksYSXQo+jN6cHgUdPLMuzufC+sRQmS+9exS8wnAEE4TP4bo4UWqXBT4Hf7YKfD7jl6w4Yyc6ZqBdeRozfSOaUofx0LAeq8LRRQXnGElx+qaK71YQ7o3GkahcC+eXO7up8aSNQAKAMha5nWooWXbt5pS7hpuokD3wJghyYAw5K9tLA4LTzWPg/7CCVKCngOW2wtYgI6wDG6EDwFj3aMvTXszIEZOd7qS7gGGSrmAlJ/bnmGlxCatRs3Kx3BMcSgzjFrGbtVpjxi7Y0x4XXH91ut8lmvVV3CU=
f68424da-da3a-4825-8fb2-0a3005e52e5a	deaa88e6-f267-4973-98c0-b5f74116c535	keyUse	ENC
65125006-03a0-466f-8ed4-58061d9d3612	deaa88e6-f267-4973-98c0-b5f74116c535	algorithm	RSA-OAEP
4cf86b2d-3b1c-4d5a-b3db-6cfcbe039619	deaa88e6-f267-4973-98c0-b5f74116c535	priority	100
129b4ab9-3cc9-4ac7-9e80-69b5e5df0662	deaa88e6-f267-4973-98c0-b5f74116c535	certificate	MIICmzCCAYMCBgGIa5kzCzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjMwNTMwMDczODAyWhcNMzMwNTMwMDczOTQyWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCqGXuGp60w6xEmPOBX3M0Lrgxhnsr4b968cPWxa77zESY5M6g3iNvWZ8a9/sZEjhTV8+f1zV1iCjnWmmZuRAkXjWM7TXCcJR9rNX2cR3dxHfpMOpwlaBJ5SAKsNLPEYj2kBGhWFiqfWSrgcI4jXJOdycokZzcc5bXCrkGRrx/anRnxNXSYSKLpcOrU2I4sqfyxZcz4zKXlbfiONXRSj6A0CNWe6Afg1SfAhWs06YaP1zypPd7nvfiXkZ3pOfaxNnvmBwKF0gro+EdNYSW5jbmfwxZ4qMYq8VQcR/BhHXq4Fp79xl+AaLGiUO9EjiA027F3Pd06YZK3bUaX6pP/iV0/AgMBAAEwDQYJKoZIhvcNAQELBQADggEBAKl+MeDDntkHBFuKBY713lTeDAi1mrBPnh7cw711b7icUKGUTDOJY5UBL02iCpWsL5Q17rifVDkWYyLOWdkp/s0TsjIvr7lIBm8gz3wXlAgkGwd+s0202NzN+DvMfwAqtWeQbNXcbu1GTtXa0JdGnwT5500d3hJ4/2kJU4mqEWSdtqqFPIdFHdJDybqD09Y3HZrGM9ESQfxTZiGcGDb8ckXCig2AxhveHehsRn3SZSquuqJo76E2iHxU6h4syXQNeG+CTyYjTNjQ+1q0H8f5yZBNZC3BC43Z5Mu7wQtLQa+Le2PFSsoNPaMNQs6dVFdgHW8gGG1AwDvhE8h5ed5kPDA=
eaac8294-a7dd-4a96-99b0-4289e2fd61ce	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
587145b4-7551-4270-a50d-84f9df9c9626	a99c7d98-7312-4c31-8db7-3aad3254e805	allow-default-scopes	true
27b512e0-411d-4af4-8f12-89917c9943dd	deaa88e6-f267-4973-98c0-b5f74116c535	privateKey	MIIEowIBAAKCAQEAqhl7hqetMOsRJjzgV9zNC64MYZ7K+G/evHD1sWu+8xEmOTOoN4jb1mfGvf7GRI4U1fPn9c1dYgo51ppmbkQJF41jO01wnCUfazV9nEd3cR36TDqcJWgSeUgCrDSzxGI9pARoVhYqn1kq4HCOI1yTncnKJGc3HOW1wq5Bka8f2p0Z8TV0mEii6XDq1NiOLKn8sWXM+Myl5W34jjV0Uo+gNAjVnugH4NUnwIVrNOmGj9c8qT3e5734l5Gd6Tn2sTZ75gcChdIK6PhHTWEluY25n8MWeKjGKvFUHEfwYR16uBae/cZfgGixolDvRI4gNNuxdz3dOmGSt21Gl+qT/4ldPwIDAQABAoIBAAImSkpV8IYpIlFYyZj/c4cadV7MC+wxz1KTg6qKhKI7udjuzy+ZRvXueWawECXDo33Erefys9bOVeBhZe2UzIY3EjIoqCvalQtDMZaTZjrQUl5uPmG2omBUyaJCR3DlSodTfiINK6kep/N08kbkhgHWqZUZYzfpRNYnlf29hQO7nTLvX4v2DwZ6ACsY0lARkHUOneVTU2ANaExCXbMg/vtBHmlPcysaNnXC3AhatRZdn6tqYhDBkbyF7XQYrBchhHQvCQx+NsdfF3tPYHHd3jIaj6tHBC7PyAEmu5qdziSZPSvQNNpJr9MGpateDE7H0vQ8jCwcetzaMPTHvFTpU6ECgYEA7Hz44AaUgYJ/2rsn8ZeFRQGz/xB54IBK34ARr/vurFkw1s1/Ow5Cgq8HWXXc6SBf5U355zA/nLmOxl6aBBSDRS1Lygvult5G9muMaufOZVSqj5uYytd4gSDmNItlq8UJptjh6OGqvbBzkBG9FDvJKhstoBN0E/pMhtnuk1cbCzECgYEAuCJFVWiXU386rXdKK+rNool3ZfFXr4Rsfpsx78TjMLuX3euaO38e3bRKouW0sWGFrDlu6HdAQxw+sRThDJNsrlBJ1MgCtmFIJG6z2uQSxKFpNh0VGCA7zVC2wE02/IKarAbK6TTsaFGKkHcXn3fzJNw/l0TFYaRiB3aNjlYw828CgYEA3aznvVdtrViecHIvJw9ZJS5LgzP2irK3fHmYGtaVC4kvdqp6MOlU/xsCUKFiykRGn7NQJZ3cgxSM+PWEeX6g7h9fg61boKAK9MIrhap0lhefKa44syr3ElO8dlSUoUa5nWR/nsSqP9U+/jUif+zqzEVdp0eU74UYZu+x6vsjpoECgYAah0V58qGqs+/eQgt7nE6YFjoPg9/gN7Hx46YkJzecM8rDfEgyPjRSOMFwCqwnyicaEwQ5lcS6Zn1ZwepSh4Lm8kZQ06ggYo+kQBbFeIqDrcWcuD/rw+kZwYEy320GoEJsemYNh0RwGx9dhOrwXLW5H8pBnvTZBnfhH2FxmlVfHQKBgAmKJ7zgtDJP2nPWfh7WezC4wIhTEcqVdQaPMnG+xf2+n+DIiFzAFLVXOuI/BvZzCsIy8VI3KTCNDtQiVI1IWEVegXW6SbvAMu40if5u6ESm8aN0yPYQZ42jVgm/x68vPvgMcqB2kdoV+GjU/L/umgeX483PNy/b6CuNSGekXhS1
b1d368f7-fe38-41ed-b249-bc10376f1dba	94bc69e8-63d9-40d7-a40c-420e7a2b0106	secret	PRTZ6jPEPCRNWEvqM41Xhg
626e5ea1-1bcb-4e04-b7b3-71e191f3a615	94bc69e8-63d9-40d7-a40c-420e7a2b0106	kid	9a7d9bef-22c2-4f59-bc95-2356ef5afb9e
f71821f5-8e07-4492-b25d-ae69d956c38d	94bc69e8-63d9-40d7-a40c-420e7a2b0106	priority	100
333247f7-4a6a-4531-af17-31e1be2259dc	8e4e2079-0b81-4237-a7f5-15be6ba17160	kid	f823ca70-0502-4090-afd8-a43f0232a512
6a487344-ae68-4efa-afdc-90908b1759ac	8e4e2079-0b81-4237-a7f5-15be6ba17160	priority	100
7d98230f-77af-4169-8774-96cc00d91be8	8e4e2079-0b81-4237-a7f5-15be6ba17160	algorithm	HS256
8247fa54-8dfe-4c26-b99d-1370c0e3073d	8e4e2079-0b81-4237-a7f5-15be6ba17160	secret	dO6GlSgIWGBrKBrj-JUrVZOUW6Pt5Lin8PWGwzOM5RWBbc46cycm7wph6qATePXv6co5blCJ_YTK8hCKCYItZQ
842d3f27-364b-499c-82be-1316740b212f	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	kid	1c03f8c3-a242-42bd-a4fc-f42aabcb808e
6b6917d5-abc9-4bd7-acd1-b270d96eca51	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	algorithm	HS256
d3ef5005-faf8-4d74-9ca3-edacef78b291	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	priority	100
0d0086f6-eae2-4941-abb1-71dff984249a	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	secret	3_LhSI2W417DzCX000HqF6SPgi0KlL_MgKrcEuotcQkSHq2NOq9QQ5W_qXEGPf_6PzbpWUW7F29glz1m_pBUFg
55b69217-e753-4157-b187-db1e8a162332	3fd3805c-e371-449c-adb6-bd7375a11a42	max-clients	200
c63d5cf4-5f95-46ce-b214-a1cc73293ef1	52b4d82e-484c-411c-9644-c1ca8bd4e513	host-sending-registration-request-must-match	true
1ad65259-f063-43cc-91c4-11eace1b50b0	52b4d82e-484c-411c-9644-c1ca8bd4e513	client-uris-must-match	true
794236b7-4493-4f2c-9769-ebf34dac3068	93bc66e1-e7e8-4915-a30b-189312230aa6	certificate	MIICozCCAYsCBgGIa5pdZjANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDApPbi1wcmVtaXNlMB4XDTIzMDUzMDA3MzkxOFoXDTMzMDUzMDA3NDA1OFowFTETMBEGA1UEAwwKT24tcHJlbWlzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4PgUnSD+jRClQGw+S8pTawbfrOYwihEHMBfsfYCdpdwMTjCFPKRlgtFARvH8JGIOSeRmrW01Il4jzktqZ4RIpBdJ1x9u+ia/rtyHwIEeDJ819Shlnt6zyLtUCPzxGxnB49a5G4VQwx+jjEU3XmEE7sQskKlYWERDl9/t6nPHJFEKhpkVrWydmO73571NS3CKOO4O3I+E3UR8V5edll64phsMyceV/rd2f0EWyWlCZkJOezzQlaNhwFZSY5SgH5NrwABPVcmqGVFkwQ025r0xr1VFkPPU5J7hObjV5RKFVOA1fCqeoayd/gpgsZk5+h6NWqqH5KfcSZpxLzWi0JHcCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAj+ZYGYm3xrXKA43fKL7X5cR2OuMK3LUfkuAOfjpEK2AG4T51o1BgIqnRfmfs3KvMhLsguyT6UpEAgKxQhajE7V8kbyCEYa99Mm6n5OX7f38fzoTHM0jmyXwmfri81gbpFnAn97SS6lG+pGL6/2C3pleNe45gVoPRcLGFedINaZt5789Xhhs0CaFtrycEvRIggE8xJhmsnRZaUptAMP5PALj/F08PQt5XDI15J7dsUyj6JfRc8jm+A5rbLq8imGqmH0znXxLRsNmgGAHgJZpuq/29D3AvDnWlZkVqthuisB+0a5fICLBALdUcRDHFlJjTlXPj8EjOBpxQzkL07VsubQ==
5c1ab548-a3e5-4191-9b4b-8bf1b879eae3	93bc66e1-e7e8-4915-a30b-189312230aa6	privateKey	MIIEowIBAAKCAQEAsng+BSdIP6NEKVAbD5LylNrBt+s5jCKEQcwF+x9gJ2l3AxOMIU8pGWC0UBG8fwkYg5J5GatbTUiXiPOS2pnhEikF0nXH276Jr+u3IfAgR4MnzX1KGWe3rPIu1QI/PEbGcHj1rkbhVDDH6OMRTdeYQTuxCyQqVhYREOX3+3qc8ckUQqGmRWtbJ2Y7vfnvU1LcIo47g7cj4TdRHxXl52WXrimGwzJx5X+t3Z/QRbJaUJmQk57PNCVo2HAVlJjlKAfk2vAAE9VyaoZUWTBDTbmvTGvVUWQ89TknuE5uNXlEoVU4DV8Kp6hrJ3+CmCxmTn6Ho1aqofkp9xJmnEvNaLQkdwIDAQABAoIBADwwHQpz4wPDNfuQzm+EKVdWJzq1k6TVBzGBcwrr2+uuv7pD32BkaAHtASJ3uNBG6wOEZF7p0VLRBnnjW0Vp2+PZ/eKqYgqTya+QmSRS7S/w5X2BoXnL5r/mtTCVH2penBHWWVS7Bsbz5Jd/7JgJ+4kUbnLJcZWyv3Kpe+ZNxZwsmQ07B8nQONr/caySZwKNlpCAxC+0aLJ3gAkAR8rvPH5epPcJrL/zKzbfvw9SloJl9+E0eJF9gBlOgudZSmRZkHZljRriC//RZgSNi2Nks1/eGxPES1C73o/BAFUt0NEHrqk4sgUU1LtTsR+QamRqNSMGV9JWjxDpJYWBS9waMmECgYEA79c/LUijG+NofyFpwQPWqHzvGmnqEpGOzrdoLBJjYOc9AL40p2/dO3JW7HuwxqprVkqtPpOttnEhipKYxf+7wHJ2mlmi82rW15yvDlDGkiCuNV4ucNAqb3SLqSc+NGZ2uXQnpWfiQQNRf+CBYgxVb4V5uKfSui+zrqHTeRubIHkCgYEAvn540LpYDLpW3oCUH7SMbX1eNkqmWoy+L7LwaODbfPj4k8KdhKqvIMizCLmzrHiQAVqpOOZy/8QxVD8hqwinc1UzU/pISNEPiFe9mYPFVJNjbmagh91Y22M/YAGghw7rMVTox/t5DKZpB9h5uKkNz4aBwbdEdz6BvVhfbxZVkG8CgYAOh1l6YsYOsG3qFZoUaSkdt8O8M+JMEak2+IFE+jAu9JMLcno6ElqyeTCuzqdcwYITDh8EhWmmfZ/shwjeJam39LcejoOCf1xYX1NzaI0+2N/0t6nUh6eqbMLxEkGAZxyWC2VDbdGU4qCTQIRV7i1Wvh0rhG8NfEpEL+VhlryE8QKBgQCeIxWeiSMxJbuZqHnOvC5bcli0j1H8F5yGsnBbUFdFLtYEq+nhyWPqvlHJ64dZpRg+14llgAF1i+Q7gNEtT9jaqJ8clshNEqhnUhdGippU9Kn1a2LWhw0Nyx1AUPl3RQ4//LHl2kAKHVdRuQaLImQhpBKxwrcmmpBPpD5NVOghJwKBgFNfmL9hsKRx7m+sAqlK5x49Y2KBXiLCh7gjCZUu9M+BqoQ/4tlPciEPaaLH3ytanmMV4gKk40S4iOVZkcAFZl92Kxm2VzPID2M8X0/2H5S/rxlGQCJ4gJ/ojTcA5UpqB1k0IIM7qYxmn7I1Flb6e3B45wxTuLEebUrYnyFlavGB
9b363552-3624-4143-b066-ff2c8e9b6605	93bc66e1-e7e8-4915-a30b-189312230aa6	priority	100
6b33d3da-4384-4c75-a60c-f338aa5b2e80	2a4271b6-e4ce-45d7-ad60-def6e56a51aa	secret	yW84u56BD1O-eSYfItC7Ug
9d929dbc-26d6-40b0-ade7-24cae36feebb	2a4271b6-e4ce-45d7-ad60-def6e56a51aa	kid	802bc735-dfd4-436d-8f99-6f0df45cf35f
4deb6e4a-3133-45e0-9f0e-6de92b2a22d6	2a4271b6-e4ce-45d7-ad60-def6e56a51aa	priority	100
f7bb7f54-ef89-4768-8b9a-3c67ee35295b	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
b22a12da-692f-4f66-a8f0-71f661e82314	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-address-mapper
af03d3bc-9507-4c8e-a295-74fcf16cb732	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
915b3453-d20d-412b-ad23-599134a37458	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-full-name-mapper
1d32ad83-f5e6-4bf9-8fd6-e17c80f2ec10	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	saml-user-property-mapper
c160c75e-ab94-4195-8329-6d594be45b22	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	saml-user-attribute-mapper
6a89f00a-1989-4d78-b1c7-f1f17d2f5380	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	saml-role-list-mapper
210d2e11-6c00-484a-a9b7-9f072bd58106	b84452da-cbd1-4077-bd02-b1130551ac9f	certificate	MIICozCCAYsCBgGIa5peQjANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDApPbi1wcmVtaXNlMB4XDTIzMDUzMDA3MzkxOFoXDTMzMDUzMDA3NDA1OFowFTETMBEGA1UEAwwKT24tcHJlbWlzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJx0upNEiQp5t5defM3fow295yjJJjZ0Reu6iCVr3vagJ55LPLHt33Y89ku//pqztDSJMkD5K2G7H75xERuLCCzvuEsdkuw5iah5BMh8MUNNYP1fOThTWg8ZlUXdViNRtFS/2H2tnPs0GpZhi83MZdl+H24MN1mbav0rhJyESFArt2b+oddljm/w6XOqpfAnzOQeGr/QAS6YfLoI3hDAeudJ+gQVdejtRJ7mIrmxU6N6/iDCWZHDMun74tTFzKfo+okrdtIYGfy0RANuTYva6jzRiLJMax0En89+aYiF26QqN+fxCrV1MEsxLbEf6OJdeL2nmfamSYCggBxxL4EAZ90CAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAg/4SCNxykA0fTRxrCYbg4fYegPbE9tsU1nKjrulB4tT+Iyoi0V9WDdEUxxtAKwIX1MwHgcrGTIosb//A/0vktlPbes+6ZOV5Z2aFONx83+x0q/wkLsLaMPR0oodCjeOfB6LHz1Lyno2UxjHzNPBoBzKktjKZNmFmWh+BV7SyZkumgWEDtz4EdCtSEkoVCiqBm4OIgHk9+IRSrFi+7fZuTZiWVuSx04a6GMFVlVfpmXlOSU5bN6oS3OoIDLsOybpfQMm+LSfJ4Y/H+TzQpnhvtdm9Aki5jo0sHVYCZPq0NdlVc/md/I0fycdFk0J+EvqWp6OW7LdIyN2CLYMNxfwthQ==
2d70f1f4-b44a-4968-869a-79584c8f75b0	b84452da-cbd1-4077-bd02-b1130551ac9f	privateKey	MIIEogIBAAKCAQEAnHS6k0SJCnm3l158zd+jDb3nKMkmNnRF67qIJWve9qAnnks8se3fdjz2S7/+mrO0NIkyQPkrYbsfvnERG4sILO+4Sx2S7DmJqHkEyHwxQ01g/V85OFNaDxmVRd1WI1G0VL/Yfa2c+zQalmGLzcxl2X4fbgw3WZtq/SuEnIRIUCu3Zv6h12WOb/Dpc6ql8CfM5B4av9ABLph8ugjeEMB650n6BBV16O1EnuYiubFTo3r+IMJZkcMy6fvi1MXMp+j6iSt20hgZ/LREA25Ni9rqPNGIskxrHQSfz35piIXbpCo35/EKtXUwSzEtsR/o4l14vaeZ9qZJgKCAHHEvgQBn3QIDAQABAoIBAA0GuPwG8kQBg1QihVCcxJYh0Au4x6oz/xhT1P8Mnqk5B2NqDzkfPYI6LCV9bETUHnZbT+hR9pcx/cAc6Ng6uKkJInZ6lV9+oOP6g3fvwyg/2ont8jUq1243apLBDWluZY3C1VMNb+sIWQhZQcsWMAquMg63DKq0wnEmvOlNKDoocEIX2DGaa4TDCPl5A2GVHw+Ul1keQZd3eP1r+iHdptlkGrJvFD/djjGAWWhSS0mdRX4HXS7qsGdd7Y5ODLe26HTdIYTDDPj9CLnNsAmMLX40BR47jCWpgZ3/HwzoWWWy4iOUT8JiTrh3DTOJC5Hlj9w/YRe8EeON3n1ZjM20zL8CgYEA01le/i5hsbimQOOUnGKJvUHoNnU/Arxe27ueqRHKAkziWgd0hY2cNTprNVk/o1W+vlSeb9O01VwQdAMs/vQglMFoSYBLlx8TSggHwXarEZ90EksOJL6KwlKdnkXnYnnSaMSi+wgEzcsk4nF7THYosADeOFlC0e4+JowpifxIrTMCgYEAvYKC47QnBThJPWe3CciFYFIR6P8epgWEOmpxE+dZtoHqopzD6BQbRH/UnMojNzdmexX4XVTgETfz+a5DiBzYsWujQX+oEcuKzGMFD+g7FKxmtqTEOikx89fojnR++l8KYYrsIW0dAlr+oihKXLZ4BuMnMslpfXQ6a/3T/XmR9q8CgYBLQyYqygWMLj82GFURo519Qf0Zd4MqzD3TberANk+DpjFs8f6ymI0p/1WyN8gLuDsmuCd7lx5sZE6PoZniaLk5f+5NTlycwjoyQM3SPRoKOogxA31T5G6xaI4skKQnU050dKG9V0uupUrLQLIxtloi4ww/cLn03CxRudQJCUgwNQKBgAuRC6waMsd+x/mXevR96KYYXD98UsKPU6K9HGm6lR8ujsOeDdb8Yy2rH67yJ3QXTYn1rVME+ygR4jI7EKQeHpu1liFJSVjMs4wF/ykZY4G/hAVhyRhDq2jWpLsNITLm2htZ/0+K+VpLc38yNleyS2EgPCQ9ZtLhZS9yLp4p7V7BAoGAZ7kt6guf9uwqazteCBX3iBk0SgSpJGR+fuGVyhhBvv3GUisbe3qlCiIZUmNZs168nDgqMmLwlp5wjL5LVejxcP7rxlw5uNhWEFBfEic56tlESAOCe0gFu4u1sjuLCGHYOZY/iQjkYpTuX33Io+zosB0zk3SeIEjMYV06Iv87fJE=
49f7bc99-5d8f-45aa-8560-521f8006f0be	b84452da-cbd1-4077-bd02-b1130551ac9f	algorithm	RSA-OAEP
d9319e81-234c-4b77-9c48-3bfe705c49d5	b84452da-cbd1-4077-bd02-b1130551ac9f	priority	100
9392c6c5-613e-4a11-b4b5-aaa93d4dfc61	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-full-name-mapper
4810d3b9-7368-49b8-95f2-c63fb18b49b3	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	saml-role-list-mapper
cb571693-24fd-42a2-adde-7aad49826044	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	saml-user-property-mapper
4424883d-d419-4160-b1d3-d6fd161dbed2	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	saml-user-attribute-mapper
8949beb7-1d04-47d1-a9c8-76fe7f801b99	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
1959e215-a639-437d-99d0-086a8a58a94e	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-address-mapper
27476cd0-562c-4466-afa6-9f9485d7fb20	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
8280df79-f360-45b7-82a2-a2182a151023	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
7ab4897d-5bf6-4a21-a8b7-746e7c84ad5f	e34baa09-e3fc-4251-9b60-9928b2f4520d	allow-default-scopes	true
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.composite_role (composite, child_role) FROM stdin;
6d932167-119c-4477-84f1-fea7c845c74f	9f3fd730-d546-41e7-952b-09a9506883cc
6d932167-119c-4477-84f1-fea7c845c74f	ea7adc17-5c39-496d-b2f5-174aa2dc680c
6d932167-119c-4477-84f1-fea7c845c74f	e384c6e7-d3e6-4637-92e8-e22cd392004f
6d932167-119c-4477-84f1-fea7c845c74f	1729bfb1-73d9-4b61-8589-f8522d76c9e2
6d932167-119c-4477-84f1-fea7c845c74f	25f247ff-b3c4-4f36-b723-ede1e57fec33
6d932167-119c-4477-84f1-fea7c845c74f	32a050fd-c3d5-4528-a30c-3eaca0a1a8f8
6d932167-119c-4477-84f1-fea7c845c74f	b6a942bc-0642-4015-a8f8-9e557dd50185
6d932167-119c-4477-84f1-fea7c845c74f	b0d21715-6ddf-42a5-b55a-3837f63d2e70
6d932167-119c-4477-84f1-fea7c845c74f	d0082667-d1a5-4029-9e34-184b04418560
6d932167-119c-4477-84f1-fea7c845c74f	48987fe8-4613-4e1b-bef2-fc058181552a
6d932167-119c-4477-84f1-fea7c845c74f	7d948938-872f-4b32-a66d-de6c1d191131
6d932167-119c-4477-84f1-fea7c845c74f	bdc1a9bd-b33e-4d81-b905-b90e93a6bae2
6d932167-119c-4477-84f1-fea7c845c74f	b3de5a6a-87a3-44e1-bb6e-2f66ab7327f3
6d932167-119c-4477-84f1-fea7c845c74f	2c0d8212-0a08-46f4-90a3-bd25f7949b09
6d932167-119c-4477-84f1-fea7c845c74f	e6fd8c1e-2ee2-46ab-a585-4945f106ad42
6d932167-119c-4477-84f1-fea7c845c74f	89f11f69-6195-47f4-a818-f5166fad29e0
6d932167-119c-4477-84f1-fea7c845c74f	14e44dec-7bf7-4474-ad7e-9540c33e9045
6d932167-119c-4477-84f1-fea7c845c74f	f9e47895-9488-4707-b305-71fa2a8bdad2
1729bfb1-73d9-4b61-8589-f8522d76c9e2	e6fd8c1e-2ee2-46ab-a585-4945f106ad42
1729bfb1-73d9-4b61-8589-f8522d76c9e2	f9e47895-9488-4707-b305-71fa2a8bdad2
25f247ff-b3c4-4f36-b723-ede1e57fec33	89f11f69-6195-47f4-a818-f5166fad29e0
3bc8c148-0469-4816-b175-b6cee105a940	b4c0525a-d4a6-4b2b-aece-eb8623fadc76
3bc8c148-0469-4816-b175-b6cee105a940	27c29c75-3b0d-46c9-abde-f232de68194c
27c29c75-3b0d-46c9-abde-f232de68194c	d03141fd-0544-406e-912b-f03a5b590a81
9e8a2e18-c087-4d16-ad8d-9e0c3f98e18c	d92edf28-8e63-4b8e-bedb-56261b29b59b
6d932167-119c-4477-84f1-fea7c845c74f	d47c5a63-351c-4006-be22-e3a4170cf100
3bc8c148-0469-4816-b175-b6cee105a940	0630deed-a301-45b5-a8fb-303f888dc074
3bc8c148-0469-4816-b175-b6cee105a940	7b99598e-9376-49ed-8bc8-8fd9db2e39bf
6d932167-119c-4477-84f1-fea7c845c74f	e08be323-9f52-45c0-b7f7-8c82e024e517
6d932167-119c-4477-84f1-fea7c845c74f	79f11bd9-197f-4f4c-823c-93d9e84a010a
6d932167-119c-4477-84f1-fea7c845c74f	4fd5a695-aa42-4137-9e74-e8a493b105a9
6d932167-119c-4477-84f1-fea7c845c74f	d3180af1-114f-4cf8-93f7-c79699d07d9f
6d932167-119c-4477-84f1-fea7c845c74f	a44c9d37-6e47-46d9-bf11-661032d57fee
6d932167-119c-4477-84f1-fea7c845c74f	24a53299-03c8-4680-ba2c-cc9962089925
6d932167-119c-4477-84f1-fea7c845c74f	34acee9b-e1be-4386-9bc9-900a519799e8
6d932167-119c-4477-84f1-fea7c845c74f	fa03af0c-fe71-4002-89cf-0180ed411aa9
6d932167-119c-4477-84f1-fea7c845c74f	53891835-4632-4f7f-b636-f2af41177981
6d932167-119c-4477-84f1-fea7c845c74f	9f0e3237-c077-493f-88ad-3efe8d91c32e
6d932167-119c-4477-84f1-fea7c845c74f	8baf43bb-8c23-4395-969f-44a69a432271
6d932167-119c-4477-84f1-fea7c845c74f	14dfb1d9-b8a7-4582-950e-7fbcfc90905c
6d932167-119c-4477-84f1-fea7c845c74f	3b36c6d4-c6cc-4f20-b37c-d2381bbf12d6
6d932167-119c-4477-84f1-fea7c845c74f	5521e737-7c5d-41b7-a780-9ae682a77d25
6d932167-119c-4477-84f1-fea7c845c74f	17a7dd75-b56c-47e1-9070-ac31e7d79188
6d932167-119c-4477-84f1-fea7c845c74f	b13f0fe8-4c62-4e5f-b65c-0d5ab97427a0
6d932167-119c-4477-84f1-fea7c845c74f	882ef03b-86ce-4454-a22b-1aea267e1d78
4fd5a695-aa42-4137-9e74-e8a493b105a9	882ef03b-86ce-4454-a22b-1aea267e1d78
4fd5a695-aa42-4137-9e74-e8a493b105a9	5521e737-7c5d-41b7-a780-9ae682a77d25
d3180af1-114f-4cf8-93f7-c79699d07d9f	17a7dd75-b56c-47e1-9070-ac31e7d79188
14301fed-c796-4dfc-9688-427859fa5a3d	8f215bd4-c353-467c-a990-30dea2e04962
2ee509b1-2f53-45ee-9673-d71e8e60a78a	20fe2009-0460-4839-8db5-72acc882762b
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	392b2dfa-3566-45ef-a21b-0e3518f8bd8a
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	f4c2141e-7651-4e28-ae5f-f01f160ce670
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	0a6c0fd7-8037-4c34-a437-bc7fe8f55a51
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	d03f9041-b734-4ea0-ad4f-c8a9c6405715
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	53d6cd2d-49da-42bf-acd7-21d06edd9147
69c368f8-4e0e-4420-93e7-918f504378e4	392b2dfa-3566-45ef-a21b-0e3518f8bd8a
69c368f8-4e0e-4420-93e7-918f504378e4	3ee7ccc9-1bc8-4218-b4fd-834c267f876b
69c368f8-4e0e-4420-93e7-918f504378e4	0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9
69c368f8-4e0e-4420-93e7-918f504378e4	6bcbf8ef-8206-4b82-8b66-37f18605d4e8
69c368f8-4e0e-4420-93e7-918f504378e4	f4c2141e-7651-4e28-ae5f-f01f160ce670
69c368f8-4e0e-4420-93e7-918f504378e4	2ee509b1-2f53-45ee-9673-d71e8e60a78a
69c368f8-4e0e-4420-93e7-918f504378e4	050929c5-9ab9-4a12-a838-6386eb3fd446
69c368f8-4e0e-4420-93e7-918f504378e4	0a6c0fd7-8037-4c34-a437-bc7fe8f55a51
69c368f8-4e0e-4420-93e7-918f504378e4	d03f9041-b734-4ea0-ad4f-c8a9c6405715
69c368f8-4e0e-4420-93e7-918f504378e4	53d6cd2d-49da-42bf-acd7-21d06edd9147
8e85020a-c3a3-4c72-ba5e-b4268bc85721	44409bce-0213-417f-9d56-99773b859c79
d03f9041-b734-4ea0-ad4f-c8a9c6405715	f4c2141e-7651-4e28-ae5f-f01f160ce670
d03f9041-b734-4ea0-ad4f-c8a9c6405715	af7d6d1e-5bf7-4799-bb7d-bfe5710d8f8a
f961073e-14fb-4e4f-894c-5167fc9a42ce	70fb6a4b-c4a0-4ace-9d57-db0765201a5a
f961073e-14fb-4e4f-894c-5167fc9a42ce	53801b14-d53e-4e86-93a8-39f12ffb1298
f961073e-14fb-4e4f-894c-5167fc9a42ce	f4c2141e-7651-4e28-ae5f-f01f160ce670
f961073e-14fb-4e4f-894c-5167fc9a42ce	f6b60156-2015-491a-9806-f7863ad39a60
f961073e-14fb-4e4f-894c-5167fc9a42ce	af7d6d1e-5bf7-4799-bb7d-bfe5710d8f8a
f961073e-14fb-4e4f-894c-5167fc9a42ce	7027be45-43d8-47f1-a990-687021281335
f961073e-14fb-4e4f-894c-5167fc9a42ce	c660e4db-fbdd-44db-86e3-66acaa901b57
f961073e-14fb-4e4f-894c-5167fc9a42ce	d03f9041-b734-4ea0-ad4f-c8a9c6405715
f961073e-14fb-4e4f-894c-5167fc9a42ce	14301fed-c796-4dfc-9688-427859fa5a3d
f961073e-14fb-4e4f-894c-5167fc9a42ce	392b2dfa-3566-45ef-a21b-0e3518f8bd8a
f961073e-14fb-4e4f-894c-5167fc9a42ce	8f215bd4-c353-467c-a990-30dea2e04962
f961073e-14fb-4e4f-894c-5167fc9a42ce	0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9
f961073e-14fb-4e4f-894c-5167fc9a42ce	0e54c49c-93ed-4977-9d0b-919126741de6
f961073e-14fb-4e4f-894c-5167fc9a42ce	13d3c77f-6b8d-4345-84f1-6f5f99bb6d2c
f961073e-14fb-4e4f-894c-5167fc9a42ce	ead4cb4d-0d86-4f41-baf3-a23928cd0561
f961073e-14fb-4e4f-894c-5167fc9a42ce	4422c51f-fc48-4fcf-9e04-65ae7a72dc06
f961073e-14fb-4e4f-894c-5167fc9a42ce	0a6c0fd7-8037-4c34-a437-bc7fe8f55a51
f961073e-14fb-4e4f-894c-5167fc9a42ce	53d6cd2d-49da-42bf-acd7-21d06edd9147
6d932167-119c-4477-84f1-fea7c845c74f	43281cdb-1d81-4997-86f5-bdb1f7521a83
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
d5f183c7-5d61-49ec-b6aa-d1210cacee35	\N	password	89b32370-7115-484c-8848-6ba37d872f18	1685432383295	\N	{"value":"DqvhRvEOqDkppKgEyWdy8Ij6QLm2yfabFJarpeW7c7I1NDuKyrtyrsaZqJ3rasIPIi9xR/5fXVjyLcDT2DcEOQ==","salt":"K+lXM9wrII/Ao+mo8DxL2Q==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
bd51ef1a-dff1-41ad-b9c5-571fc5b0ddf7	\N	password	af0b953e-9b5d-40af-a8db-a1783bf291b8	1685432710103	My password	{"value":"lPkA6qjncHOE71iAV+zYHGjrGkwC7BUI7meDlCjdktcQnNDFMRtY5OAmkhEyKkpMspp8YZ7lcSNmA9KPQ4Y0sg==","salt":"RGBArNSttDZ+KNEjXkqLRQ==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
b13b3da1-69ce-4653-8abc-4913fe343515	\N	password	e13e313c-352f-4db2-8db4-477273b39005	1685693389372	\N	{"value":"japHzdACXSz7NW4217r1VGdfDs3mvq2m5IFy+GzNXdRTXjCWWBW5h+4CKB6GMeSqO8apjs+iWCwbATfr60Dvug==","salt":"Kfm49r4a4o6O3FKSXTdF4g==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
5d3f8ca7-05e1-48e4-8de2-e33da28590a0	\N	password	ed9756fb-0a0f-465d-940e-045d7e1dcdc8	1685696893068	\N	{"value":"CWVH47UorjDY+e+rEvg+ax61GYEmFDKCKh2FVDbTw2VOzhJhZ1Q+qeRJC9ngDKZNryXyRmqJxEl11Q5apfYveg==","salt":"UuLLcAH+0HHTrQgo1Y69fA==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2023-05-30 07:39:36.216055	1	EXECUTED	8:bda77d94bf90182a1e30c24f1c155ec7	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.8.0	\N	\N	5432375470
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2023-05-30 07:39:36.23078	2	MARK_RAN	8:1ecb330f30986693d1cba9ab579fa219	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.8.0	\N	\N	5432375470
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2023-05-30 07:39:36.312657	3	EXECUTED	8:cb7ace19bc6d959f305605d255d4c843	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.8.0	\N	\N	5432375470
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2023-05-30 07:39:36.320455	4	EXECUTED	8:80230013e961310e6872e871be424a63	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.8.0	\N	\N	5432375470
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2023-05-30 07:39:36.494897	5	EXECUTED	8:67f4c20929126adc0c8e9bf48279d244	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.8.0	\N	\N	5432375470
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2023-05-30 07:39:36.500099	6	MARK_RAN	8:7311018b0b8179ce14628ab412bb6783	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.8.0	\N	\N	5432375470
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2023-05-30 07:39:36.667447	7	EXECUTED	8:037ba1216c3640f8785ee6b8e7c8e3c1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.8.0	\N	\N	5432375470
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2023-05-30 07:39:36.673066	8	MARK_RAN	8:7fe6ffe4af4df289b3157de32c624263	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.8.0	\N	\N	5432375470
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2023-05-30 07:39:36.684101	9	EXECUTED	8:9c136bc3187083a98745c7d03bc8a303	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.8.0	\N	\N	5432375470
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2023-05-30 07:39:36.862504	10	EXECUTED	8:b5f09474dca81fb56a97cf5b6553d331	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.8.0	\N	\N	5432375470
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2023-05-30 07:39:36.985837	11	EXECUTED	8:ca924f31bd2a3b219fdcfe78c82dacf4	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.8.0	\N	\N	5432375470
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2023-05-30 07:39:36.992752	12	MARK_RAN	8:8acad7483e106416bcfa6f3b824a16cd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.8.0	\N	\N	5432375470
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2023-05-30 07:39:37.040808	13	EXECUTED	8:9b1266d17f4f87c78226f5055408fd5e	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.8.0	\N	\N	5432375470
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-05-30 07:39:37.078076	14	EXECUTED	8:d80ec4ab6dbfe573550ff72396c7e910	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.8.0	\N	\N	5432375470
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-05-30 07:39:37.080759	15	MARK_RAN	8:d86eb172171e7c20b9c849b584d147b2	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	5432375470
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-05-30 07:39:37.085031	16	MARK_RAN	8:5735f46f0fa60689deb0ecdc2a0dea22	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.8.0	\N	\N	5432375470
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-05-30 07:39:37.091342	17	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.8.0	\N	\N	5432375470
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2023-05-30 07:39:37.178725	18	EXECUTED	8:5c1a8fd2014ac7fc43b90a700f117b23	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.8.0	\N	\N	5432375470
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2023-05-30 07:39:37.258646	19	EXECUTED	8:1f6c2c2dfc362aff4ed75b3f0ef6b331	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.8.0	\N	\N	5432375470
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2023-05-30 07:39:37.266615	20	EXECUTED	8:dee9246280915712591f83a127665107	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.8.0	\N	\N	5432375470
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-05-30 07:39:37.962661	45	EXECUTED	8:a164ae073c56ffdbc98a615493609a52	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.8.0	\N	\N	5432375470
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2023-05-30 07:39:37.270353	21	MARK_RAN	8:9eb2ee1fa8ad1c5e426421a6f8fdfa6a	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.8.0	\N	\N	5432375470
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2023-05-30 07:39:37.276254	22	MARK_RAN	8:dee9246280915712591f83a127665107	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.8.0	\N	\N	5432375470
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2023-05-30 07:39:37.335148	23	EXECUTED	8:d9fa18ffa355320395b86270680dd4fe	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.8.0	\N	\N	5432375470
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2023-05-30 07:39:37.345037	24	EXECUTED	8:90cff506fedb06141ffc1c71c4a1214c	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.8.0	\N	\N	5432375470
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2023-05-30 07:39:37.347046	25	MARK_RAN	8:11a788aed4961d6d29c427c063af828c	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.8.0	\N	\N	5432375470
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2023-05-30 07:39:37.386194	26	EXECUTED	8:a4218e51e1faf380518cce2af5d39b43	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.8.0	\N	\N	5432375470
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2023-05-30 07:39:37.495138	27	EXECUTED	8:d9e9a1bfaa644da9952456050f07bbdc	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.8.0	\N	\N	5432375470
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2023-05-30 07:39:37.500063	28	EXECUTED	8:d1bf991a6163c0acbfe664b615314505	update tableName=RESOURCE_SERVER_POLICY		\N	4.8.0	\N	\N	5432375470
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2023-05-30 07:39:37.587424	29	EXECUTED	8:88a743a1e87ec5e30bf603da68058a8c	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.8.0	\N	\N	5432375470
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2023-05-30 07:39:37.609023	30	EXECUTED	8:c5517863c875d325dea463d00ec26d7a	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.8.0	\N	\N	5432375470
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2023-05-30 07:39:37.639686	31	EXECUTED	8:ada8b4833b74a498f376d7136bc7d327	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.8.0	\N	\N	5432375470
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2023-05-30 07:39:37.650316	32	EXECUTED	8:b9b73c8ea7299457f99fcbb825c263ba	customChange		\N	4.8.0	\N	\N	5432375470
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-05-30 07:39:37.660795	33	EXECUTED	8:07724333e625ccfcfc5adc63d57314f3	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	5432375470
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-05-30 07:39:37.663135	34	MARK_RAN	8:8b6fd445958882efe55deb26fc541a7b	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.8.0	\N	\N	5432375470
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-05-30 07:39:37.712459	35	EXECUTED	8:29b29cfebfd12600897680147277a9d7	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.8.0	\N	\N	5432375470
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2023-05-30 07:39:37.720017	36	EXECUTED	8:73ad77ca8fd0410c7f9f15a471fa52bc	addColumn tableName=REALM		\N	4.8.0	\N	\N	5432375470
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-05-30 07:39:37.728879	37	EXECUTED	8:64f27a6fdcad57f6f9153210f2ec1bdb	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	5432375470
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2023-05-30 07:39:37.735133	38	EXECUTED	8:27180251182e6c31846c2ddab4bc5781	addColumn tableName=FED_USER_CONSENT		\N	4.8.0	\N	\N	5432375470
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2023-05-30 07:39:37.742545	39	EXECUTED	8:d56f201bfcfa7a1413eb3e9bc02978f9	addColumn tableName=IDENTITY_PROVIDER		\N	4.8.0	\N	\N	5432375470
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-05-30 07:39:37.744633	40	MARK_RAN	8:91f5522bf6afdc2077dfab57fbd3455c	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.8.0	\N	\N	5432375470
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-05-30 07:39:37.746616	41	MARK_RAN	8:0f01b554f256c22caeb7d8aee3a1cdc8	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.8.0	\N	\N	5432375470
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2023-05-30 07:39:37.756937	42	EXECUTED	8:ab91cf9cee415867ade0e2df9651a947	customChange		\N	4.8.0	\N	\N	5432375470
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-05-30 07:39:37.945644	43	EXECUTED	8:ceac9b1889e97d602caf373eadb0d4b7	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.8.0	\N	\N	5432375470
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2023-05-30 07:39:37.955299	44	EXECUTED	8:84b986e628fe8f7fd8fd3c275c5259f2	addColumn tableName=USER_ENTITY		\N	4.8.0	\N	\N	5432375470
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-05-30 07:39:37.96989	46	EXECUTED	8:70a2b4f1f4bd4dbf487114bdb1810e64	customChange		\N	4.8.0	\N	\N	5432375470
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-05-30 07:39:37.972848	47	MARK_RAN	8:7be68b71d2f5b94b8df2e824f2860fa2	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.8.0	\N	\N	5432375470
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-05-30 07:39:38.035118	48	EXECUTED	8:bab7c631093c3861d6cf6144cd944982	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.8.0	\N	\N	5432375470
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-05-30 07:39:38.043106	49	EXECUTED	8:fa809ac11877d74d76fe40869916daad	addColumn tableName=REALM		\N	4.8.0	\N	\N	5432375470
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2023-05-30 07:39:38.104295	50	EXECUTED	8:fac23540a40208f5f5e326f6ceb4d291	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.8.0	\N	\N	5432375470
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2023-05-30 07:39:38.144748	51	EXECUTED	8:2612d1b8a97e2b5588c346e817307593	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.8.0	\N	\N	5432375470
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2023-05-30 07:39:38.148676	52	EXECUTED	8:9842f155c5db2206c88bcb5d1046e941	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	5432375470
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2023-05-30 07:39:38.154473	53	EXECUTED	8:2e12e06e45498406db72d5b3da5bbc76	update tableName=REALM		\N	4.8.0	\N	\N	5432375470
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2023-05-30 07:39:38.160817	54	EXECUTED	8:33560e7c7989250c40da3abdabdc75a4	update tableName=CLIENT		\N	4.8.0	\N	\N	5432375470
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-05-30 07:39:38.169018	55	EXECUTED	8:87a8d8542046817a9107c7eb9cbad1cd	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.8.0	\N	\N	5432375470
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-05-30 07:39:38.17629	56	EXECUTED	8:3ea08490a70215ed0088c273d776311e	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.8.0	\N	\N	5432375470
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-05-30 07:39:38.208296	57	EXECUTED	8:2d56697c8723d4592ab608ce14b6ed68	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.8.0	\N	\N	5432375470
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-05-30 07:39:38.356692	58	EXECUTED	8:3e423e249f6068ea2bbe48bf907f9d86	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.8.0	\N	\N	5432375470
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2023-05-30 07:39:38.392518	59	EXECUTED	8:15cabee5e5df0ff099510a0fc03e4103	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.8.0	\N	\N	5432375470
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2023-05-30 07:39:38.398209	60	EXECUTED	8:4b80200af916ac54d2ffbfc47918ab0e	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.8.0	\N	\N	5432375470
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2023-05-30 07:39:38.41179	61	EXECUTED	8:66564cd5e168045d52252c5027485bbb	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.8.0	\N	\N	5432375470
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2023-05-30 07:39:38.418391	62	EXECUTED	8:1c7064fafb030222be2bd16ccf690f6f	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.8.0	\N	\N	5432375470
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2023-05-30 07:39:38.423059	63	EXECUTED	8:2de18a0dce10cdda5c7e65c9b719b6e5	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.8.0	\N	\N	5432375470
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2023-05-30 07:39:38.428274	64	EXECUTED	8:03e413dd182dcbd5c57e41c34d0ef682	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.8.0	\N	\N	5432375470
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2023-05-30 07:39:38.43143	65	EXECUTED	8:d27b42bb2571c18fbe3fe4e4fb7582a7	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.8.0	\N	\N	5432375470
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2023-05-30 07:39:38.453015	66	EXECUTED	8:698baf84d9fd0027e9192717c2154fb8	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.8.0	\N	\N	5432375470
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2023-05-30 07:39:38.462242	67	EXECUTED	8:ced8822edf0f75ef26eb51582f9a821a	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.8.0	\N	\N	5432375470
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2023-05-30 07:39:38.469243	68	EXECUTED	8:f0abba004cf429e8afc43056df06487d	addColumn tableName=REALM		\N	4.8.0	\N	\N	5432375470
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2023-05-30 07:39:38.485263	69	EXECUTED	8:6662f8b0b611caa359fcf13bf63b4e24	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.8.0	\N	\N	5432375470
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2023-05-30 07:39:38.494995	70	EXECUTED	8:9e6b8009560f684250bdbdf97670d39e	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.8.0	\N	\N	5432375470
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2023-05-30 07:39:38.499224	71	EXECUTED	8:4223f561f3b8dc655846562b57bb502e	addColumn tableName=RESOURCE_SERVER		\N	4.8.0	\N	\N	5432375470
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-05-30 07:39:38.511409	72	EXECUTED	8:215a31c398b363ce383a2b301202f29e	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.8.0	\N	\N	5432375470
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-05-30 07:39:38.520792	73	EXECUTED	8:83f7a671792ca98b3cbd3a1a34862d3d	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.8.0	\N	\N	5432375470
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-05-30 07:39:38.5237	74	MARK_RAN	8:f58ad148698cf30707a6efbdf8061aa7	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.8.0	\N	\N	5432375470
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-05-30 07:39:38.561771	75	EXECUTED	8:79e4fd6c6442980e58d52ffc3ee7b19c	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.8.0	\N	\N	5432375470
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-05-30 07:39:38.57105	76	EXECUTED	8:87af6a1e6d241ca4b15801d1f86a297d	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.8.0	\N	\N	5432375470
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-05-30 07:39:38.577332	77	EXECUTED	8:b44f8d9b7b6ea455305a6d72a200ed15	addColumn tableName=CLIENT		\N	4.8.0	\N	\N	5432375470
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-05-30 07:39:38.579517	78	MARK_RAN	8:2d8ed5aaaeffd0cb004c046b4a903ac5	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.8.0	\N	\N	5432375470
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-05-30 07:39:38.604748	79	EXECUTED	8:e290c01fcbc275326c511633f6e2acde	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.8.0	\N	\N	5432375470
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-05-30 07:39:38.609784	80	MARK_RAN	8:c9db8784c33cea210872ac2d805439f8	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.8.0	\N	\N	5432375470
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-05-30 07:39:38.617928	81	EXECUTED	8:95b676ce8fc546a1fcfb4c92fae4add5	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.8.0	\N	\N	5432375470
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-05-30 07:39:38.620175	82	MARK_RAN	8:38a6b2a41f5651018b1aca93a41401e5	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	5432375470
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-05-30 07:39:38.626788	83	EXECUTED	8:3fb99bcad86a0229783123ac52f7609c	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	5432375470
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-05-30 07:39:38.631392	84	MARK_RAN	8:64f27a6fdcad57f6f9153210f2ec1bdb	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	5432375470
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-05-30 07:39:38.639422	85	EXECUTED	8:ab4f863f39adafd4c862f7ec01890abc	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.8.0	\N	\N	5432375470
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2023-05-30 07:39:38.647451	86	EXECUTED	8:13c419a0eb336e91ee3a3bf8fda6e2a7	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.8.0	\N	\N	5432375470
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2023-05-30 07:39:38.661392	87	EXECUTED	8:e3fb1e698e0471487f51af1ed80fe3ac	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.8.0	\N	\N	5432375470
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2023-05-30 07:39:38.671579	88	EXECUTED	8:babadb686aab7b56562817e60bf0abd0	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.8.0	\N	\N	5432375470
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.680746	89	EXECUTED	8:72d03345fda8e2f17093d08801947773	addColumn tableName=REALM; customChange		\N	4.8.0	\N	\N	5432375470
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.691769	90	EXECUTED	8:61c9233951bd96ffecd9ba75f7d978a4	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.8.0	\N	\N	5432375470
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.696684	91	EXECUTED	8:ea82e6ad945cec250af6372767b25525	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	5432375470
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.71111	92	EXECUTED	8:d3f4a33f41d960ddacd7e2ef30d126b3	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.8.0	\N	\N	5432375470
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.713319	93	MARK_RAN	8:1284a27fbd049d65831cb6fc07c8a783	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.8.0	\N	\N	5432375470
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.72638	94	EXECUTED	8:9d11b619db2ae27c25853b8a37cd0dea	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.8.0	\N	\N	5432375470
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.728468	95	MARK_RAN	8:3002bb3997451bb9e8bac5c5cd8d6327	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.8.0	\N	\N	5432375470
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-05-30 07:39:38.736543	96	EXECUTED	8:dfbee0d6237a23ef4ccbb7a4e063c163	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.8.0	\N	\N	5432375470
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-05-30 07:39:38.75027	97	EXECUTED	8:75f3e372df18d38c62734eebb986b960	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	5432375470
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-05-30 07:39:38.753286	98	MARK_RAN	8:7fee73eddf84a6035691512c85637eef	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	5432375470
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-05-30 07:39:38.770153	99	MARK_RAN	8:7a11134ab12820f999fbf3bb13c3adc8	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	5432375470
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-05-30 07:39:38.779555	100	EXECUTED	8:c0f6eaac1f3be773ffe54cb5b8482b70	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	5432375470
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-05-30 07:39:38.781653	101	MARK_RAN	8:18186f0008b86e0f0f49b0c4d0e842ac	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	5432375470
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-05-30 07:39:38.788656	102	EXECUTED	8:09c2780bcb23b310a7019d217dc7b433	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.8.0	\N	\N	5432375470
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-05-30 07:39:38.803557	103	EXECUTED	8:276a44955eab693c970a42880197fff2	customChange		\N	4.8.0	\N	\N	5432375470
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2023-05-30 07:39:38.815018	104	EXECUTED	8:ba8ee3b694d043f2bfc1a1079d0760d7	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.8.0	\N	\N	5432375470
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2023-05-30 07:39:38.826506	105	EXECUTED	8:5e06b1d75f5d17685485e610c2851b17	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.8.0	\N	\N	5432375470
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2023-05-30 07:39:38.834991	106	EXECUTED	8:4b80546c1dc550ac552ee7b24a4ab7c0	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.8.0	\N	\N	5432375470
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2023-05-30 07:39:38.853064	107	EXECUTED	8:af510cd1bb2ab6339c45372f3e491696	customChange		\N	4.8.0	\N	\N	5432375470
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-05-30 07:39:38.86226	108	EXECUTED	8:05c99fc610845ef66ee812b7921af0ef	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.8.0	\N	\N	5432375470
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-05-30 07:39:38.864561	109	MARK_RAN	8:314e803baf2f1ec315b3464e398b8247	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.8.0	\N	\N	5432375470
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-05-30 07:39:38.873818	110	EXECUTED	8:56e4677e7e12556f70b604c573840100	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	5432375470
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
5ed7970f-211a-4f6b-8938-f50938e90423	8a85ca55-eb51-410e-b234-71260cbc1731	f
5ed7970f-211a-4f6b-8938-f50938e90423	46c7c663-c060-44e9-be16-85663441d262	t
5ed7970f-211a-4f6b-8938-f50938e90423	971c4ebb-6c43-4748-94b6-a10e7421c561	t
5ed7970f-211a-4f6b-8938-f50938e90423	5d755794-7705-45a2-9344-55b27bd7b857	t
5ed7970f-211a-4f6b-8938-f50938e90423	b555b4f6-4df9-4f43-bb30-556b88592c74	f
5ed7970f-211a-4f6b-8938-f50938e90423	d4d29ad6-8d91-4f6b-b229-e1cc470ae519	f
5ed7970f-211a-4f6b-8938-f50938e90423	5eee0da0-11f3-4ba2-8cc1-e3dec677c683	t
5ed7970f-211a-4f6b-8938-f50938e90423	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd	t
5ed7970f-211a-4f6b-8938-f50938e90423	f32fff6f-7966-4f0f-9d25-52e8979295f0	f
5ed7970f-211a-4f6b-8938-f50938e90423	98585029-d919-48c4-8b71-03a8c293427e	t
On-premise	445e57d8-6cb8-49a7-a566-480c1b754409	t
On-premise	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
On-premise	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
On-premise	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
On-premise	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
On-premise	9db74845-4196-4859-82b4-dd4ac268d672	t
On-premise	ac87c569-2002-45ff-b330-b4fc5303051e	f
On-premise	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
On-premise	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
On-premise	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
3bc8c148-0469-4816-b175-b6cee105a940	5ed7970f-211a-4f6b-8938-f50938e90423	f	${role_default-roles}	default-roles-master	5ed7970f-211a-4f6b-8938-f50938e90423	\N	\N
6d932167-119c-4477-84f1-fea7c845c74f	5ed7970f-211a-4f6b-8938-f50938e90423	f	${role_admin}	admin	5ed7970f-211a-4f6b-8938-f50938e90423	\N	\N
9f3fd730-d546-41e7-952b-09a9506883cc	5ed7970f-211a-4f6b-8938-f50938e90423	f	${role_create-realm}	create-realm	5ed7970f-211a-4f6b-8938-f50938e90423	\N	\N
ea7adc17-5c39-496d-b2f5-174aa2dc680c	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_create-client}	create-client	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
e384c6e7-d3e6-4637-92e8-e22cd392004f	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_view-realm}	view-realm	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
1729bfb1-73d9-4b61-8589-f8522d76c9e2	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_view-users}	view-users	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
25f247ff-b3c4-4f36-b723-ede1e57fec33	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_view-clients}	view-clients	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
32a050fd-c3d5-4528-a30c-3eaca0a1a8f8	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_view-events}	view-events	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
b6a942bc-0642-4015-a8f8-9e557dd50185	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_view-identity-providers}	view-identity-providers	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
b0d21715-6ddf-42a5-b55a-3837f63d2e70	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_view-authorization}	view-authorization	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
d0082667-d1a5-4029-9e34-184b04418560	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_manage-realm}	manage-realm	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
48987fe8-4613-4e1b-bef2-fc058181552a	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_manage-users}	manage-users	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
7d948938-872f-4b32-a66d-de6c1d191131	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_manage-clients}	manage-clients	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
bdc1a9bd-b33e-4d81-b905-b90e93a6bae2	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_manage-events}	manage-events	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
b3de5a6a-87a3-44e1-bb6e-2f66ab7327f3	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_manage-identity-providers}	manage-identity-providers	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
2c0d8212-0a08-46f4-90a3-bd25f7949b09	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_manage-authorization}	manage-authorization	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
e6fd8c1e-2ee2-46ab-a585-4945f106ad42	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_query-users}	query-users	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
89f11f69-6195-47f4-a818-f5166fad29e0	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_query-clients}	query-clients	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
14e44dec-7bf7-4474-ad7e-9540c33e9045	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_query-realms}	query-realms	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
f9e47895-9488-4707-b305-71fa2a8bdad2	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_query-groups}	query-groups	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
b4c0525a-d4a6-4b2b-aece-eb8623fadc76	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_view-profile}	view-profile	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
27c29c75-3b0d-46c9-abde-f232de68194c	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_manage-account}	manage-account	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
d03141fd-0544-406e-912b-f03a5b590a81	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_manage-account-links}	manage-account-links	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
f69e28e5-1b97-48ad-bdea-c523a7d24acb	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_view-applications}	view-applications	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
d92edf28-8e63-4b8e-bedb-56261b29b59b	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_view-consent}	view-consent	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
9e8a2e18-c087-4d16-ad8d-9e0c3f98e18c	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_manage-consent}	manage-consent	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
1713d146-25b9-4c95-9c76-8234d8f48e47	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_view-groups}	view-groups	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
010a24e5-4167-42ea-bd6f-52692c34beae	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	t	${role_delete-account}	delete-account	5ed7970f-211a-4f6b-8938-f50938e90423	c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	\N
ce80738e-2d1e-4f31-8c49-504b38d74f23	f653a789-b4d1-42a6-8265-063cf05d6594	t	${role_read-token}	read-token	5ed7970f-211a-4f6b-8938-f50938e90423	f653a789-b4d1-42a6-8265-063cf05d6594	\N
d47c5a63-351c-4006-be22-e3a4170cf100	64b186bc-71c6-464e-9796-0387b69e11a3	t	${role_impersonation}	impersonation	5ed7970f-211a-4f6b-8938-f50938e90423	64b186bc-71c6-464e-9796-0387b69e11a3	\N
0630deed-a301-45b5-a8fb-303f888dc074	5ed7970f-211a-4f6b-8938-f50938e90423	f	${role_offline-access}	offline_access	5ed7970f-211a-4f6b-8938-f50938e90423	\N	\N
7b99598e-9376-49ed-8bc8-8fd9db2e39bf	5ed7970f-211a-4f6b-8938-f50938e90423	f	${role_uma_authorization}	uma_authorization	5ed7970f-211a-4f6b-8938-f50938e90423	\N	\N
69c368f8-4e0e-4420-93e7-918f504378e4	On-premise	f	${role_default-roles}	default-roles-amrit	On-premise	\N	\N
e08be323-9f52-45c0-b7f7-8c82e024e517	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_create-client}	create-client	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
79f11bd9-197f-4f4c-823c-93d9e84a010a	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_view-realm}	view-realm	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
4fd5a695-aa42-4137-9e74-e8a493b105a9	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_view-users}	view-users	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
d3180af1-114f-4cf8-93f7-c79699d07d9f	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_view-clients}	view-clients	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
a44c9d37-6e47-46d9-bf11-661032d57fee	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_view-events}	view-events	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
24a53299-03c8-4680-ba2c-cc9962089925	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_view-identity-providers}	view-identity-providers	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
34acee9b-e1be-4386-9bc9-900a519799e8	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_view-authorization}	view-authorization	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
fa03af0c-fe71-4002-89cf-0180ed411aa9	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_manage-realm}	manage-realm	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
53891835-4632-4f7f-b636-f2af41177981	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_manage-users}	manage-users	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
9f0e3237-c077-493f-88ad-3efe8d91c32e	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_manage-clients}	manage-clients	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
8baf43bb-8c23-4395-969f-44a69a432271	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_manage-events}	manage-events	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
14dfb1d9-b8a7-4582-950e-7fbcfc90905c	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_manage-identity-providers}	manage-identity-providers	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
3b36c6d4-c6cc-4f20-b37c-d2381bbf12d6	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_manage-authorization}	manage-authorization	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
5521e737-7c5d-41b7-a780-9ae682a77d25	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_query-users}	query-users	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
17a7dd75-b56c-47e1-9070-ac31e7d79188	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_query-clients}	query-clients	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
b13f0fe8-4c62-4e5f-b65c-0d5ab97427a0	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_query-realms}	query-realms	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
882ef03b-86ce-4454-a22b-1aea267e1d78	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_query-groups}	query-groups	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
3ee7ccc9-1bc8-4218-b4fd-834c267f876b	On-premise	f	${role_offline-access}	offline_access	On-premise	\N	\N
6bcbf8ef-8206-4b82-8b66-37f18605d4e8	On-premise	f	${role_uma_authorization}	uma_authorization	On-premise	\N	\N
70fb6a4b-c4a0-4ace-9d57-db0765201a5a	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-authorization}	manage-authorization	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
53801b14-d53e-4e86-93a8-39f12ffb1298	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_create-client}	create-client	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
f4c2141e-7651-4e28-ae5f-f01f160ce670	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-users}	query-users	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
f6b60156-2015-491a-9806-f7863ad39a60	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-authorization}	view-authorization	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
af7d6d1e-5bf7-4799-bb7d-bfe5710d8f8a	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-groups}	query-groups	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
7027be45-43d8-47f1-a990-687021281335	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-events}	view-events	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
c660e4db-fbdd-44db-86e3-66acaa901b57	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-identity-providers}	view-identity-providers	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
d03f9041-b734-4ea0-ad4f-c8a9c6405715	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-users}	view-users	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
14301fed-c796-4dfc-9688-427859fa5a3d	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-clients}	view-clients	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
392b2dfa-3566-45ef-a21b-0e3518f8bd8a	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-realms}	query-realms	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
8f215bd4-c353-467c-a990-30dea2e04962	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-clients}	query-clients	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-realm}	view-realm	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
0e54c49c-93ed-4977-9d0b-919126741de6	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-events}	manage-events	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
13d3c77f-6b8d-4345-84f1-6f5f99bb6d2c	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_impersonation}	impersonation	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
ead4cb4d-0d86-4f41-baf3-a23928cd0561	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-identity-providers}	manage-identity-providers	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
4422c51f-fc48-4fcf-9e04-65ae7a72dc06	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-clients}	manage-clients	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
0a6c0fd7-8037-4c34-a437-bc7fe8f55a51	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-realm}	manage-realm	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
f961073e-14fb-4e4f-894c-5167fc9a42ce	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_realm-admin}	realm-admin	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
53d6cd2d-49da-42bf-acd7-21d06edd9147	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-users}	manage-users	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	4381c433-5988-418a-bc71-177bb46e873a	t	Users managements	user_mgt	On-premise	4381c433-5988-418a-bc71-177bb46e873a	\N
b432d132-af2e-4fd6-a3fb-80c7ff4c183b	82b820b4-c7f1-4946-8e97-7cda75eca5a3	t	${role_read-token}	read-token	On-premise	82b820b4-c7f1-4946-8e97-7cda75eca5a3	\N
403bd78d-d2a0-4d23-a76f-73e732b3d864	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-applications}	view-applications	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
9add80b2-bd14-4e8c-87be-01ed5464849f	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_delete-account}	delete-account	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
8e85020a-c3a3-4c72-ba5e-b4268bc85721	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_manage-consent}	manage-consent	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
20fe2009-0460-4839-8db5-72acc882762b	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_manage-account-links}	manage-account-links	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
2ee509b1-2f53-45ee-9673-d71e8e60a78a	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_manage-account}	manage-account	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
01ded32e-7299-4877-b1de-ceab307fdf0d	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-groups}	view-groups	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
050929c5-9ab9-4a12-a838-6386eb3fd446	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-profile}	view-profile	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
44409bce-0213-417f-9d56-99773b859c79	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-consent}	view-consent	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
43281cdb-1d81-4997-86f5-bdb1f7521a83	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	t	${role_impersonation}	impersonation	5ed7970f-211a-4f6b-8938-f50938e90423	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.migration_model (id, version, update_time) FROM stdin;
xhu3c	20.0.2	1685432379
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
b824deb4-bc54-4783-bcf6-7d89b7b774f0	audience resolve	openid-connect	oidc-audience-resolve-mapper	138412d0-f1d5-4a20-90b3-b5ce26d89b93	\N
b687a1cf-9126-42d3-9363-d05d4fdaa7fd	locale	openid-connect	oidc-usermodel-attribute-mapper	ca64abba-762f-4ffb-9423-6a53838c84a8	\N
f9240e77-6d41-4a5f-9171-dd0788d575ae	role list	saml	saml-role-list-mapper	\N	46c7c663-c060-44e9-be16-85663441d262
ce4642d0-7d4f-4347-a797-95935dd23b73	full name	openid-connect	oidc-full-name-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
b128be00-fadb-49f5-8447-5d5acb380397	family name	openid-connect	oidc-usermodel-property-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
38237243-a17b-45e2-aa64-c9416b3dcaa7	given name	openid-connect	oidc-usermodel-property-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
ab7d212a-c490-41ca-ae79-b3da584b9d8f	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
254ca24a-b3a1-4287-ba3e-13b740e104bd	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
bd628834-c40a-49e0-855d-00fd771dcdbb	username	openid-connect	oidc-usermodel-property-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
623910df-77b8-487a-b99e-2df4e7794e6f	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
ac51e3b2-0555-4dd5-95d6-7e8404e32226	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
d1f2b246-e790-4a09-9a09-158211a8596a	website	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
981548f0-b411-47de-830b-a500b78cb1bf	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
39372e77-95d2-4e0a-95e2-07e844528e6a	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
ea395d5a-ccc3-43a4-a34a-031327954d3d	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
f7bd06d9-2604-42bc-8e46-8928be942913	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
357463ec-9b65-45da-94ca-5077169e516d	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	971c4ebb-6c43-4748-94b6-a10e7421c561
820e79ab-422f-4253-828a-89273dcf0b4b	email	openid-connect	oidc-usermodel-property-mapper	\N	5d755794-7705-45a2-9344-55b27bd7b857
c3e9b475-23b1-4a68-bc72-ccd23f6891d8	email verified	openid-connect	oidc-usermodel-property-mapper	\N	5d755794-7705-45a2-9344-55b27bd7b857
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	address	openid-connect	oidc-address-mapper	\N	b555b4f6-4df9-4f43-bb30-556b88592c74
3d640ec8-81ae-4648-8d5a-219d271277d1	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	d4d29ad6-8d91-4f6b-b229-e1cc470ae519
e89c0bf0-0526-44a8-b4bc-3ea5a427db55	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	d4d29ad6-8d91-4f6b-b229-e1cc470ae519
bd3ce471-db5e-4e94-93cb-b6078520246e	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	5eee0da0-11f3-4ba2-8cc1-e3dec677c683
e99a5d2b-9482-475b-93c9-3e29079eac1f	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	5eee0da0-11f3-4ba2-8cc1-e3dec677c683
00ed8369-dc60-4dd9-9b8a-2520fa08f2f3	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	5eee0da0-11f3-4ba2-8cc1-e3dec677c683
7e1f4486-338a-41b6-8819-f4eb72808cb4	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	c7ed40ca-da9f-4c1a-8a1f-0d65ad7ce8fd
f94264f6-dd99-4aa3-b97d-c7b8825e69cd	upn	openid-connect	oidc-usermodel-property-mapper	\N	f32fff6f-7966-4f0f-9d25-52e8979295f0
7753e5e2-43d2-4d1a-8c8d-dd9217b559df	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	f32fff6f-7966-4f0f-9d25-52e8979295f0
4eb261f7-48b2-477f-b37c-0c1eb0ecbbf1	acr loa level	openid-connect	oidc-acr-mapper	\N	98585029-d919-48c4-8b71-03a8c293427e
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	79cee3fc-a552-47d4-8deb-7fe5b231bfe1
387125c5-5735-482d-b6c1-cb8cd02848f2	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	79cee3fc-a552-47d4-8deb-7fe5b231bfe1
ec55de66-9ba8-401b-81a6-648deaa4dcdb	email verified	openid-connect	oidc-usermodel-property-mapper	\N	fb5fb072-87e0-490e-9dba-3bfaa677b35e
0132cd45-2832-4fb2-b3da-deb2bde01f7b	email	openid-connect	oidc-usermodel-property-mapper	\N	fb5fb072-87e0-490e-9dba-3bfaa677b35e
016d0122-6dff-486c-b1ac-6417db3b7c16	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	b97a5f52-b8bf-4313-a458-d5af0b16c629
9015add1-eb40-4c3e-975e-bdd82293e7ce	upn	openid-connect	oidc-usermodel-property-mapper	\N	b97a5f52-b8bf-4313-a458-d5af0b16c629
3a811bd1-d368-4091-b7ae-c8e4ef05acc1	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442
2acd9feb-49ca-42f5-ad96-70cd81d217e5	acr loa level	openid-connect	oidc-acr-mapper	\N	9db74845-4196-4859-82b4-dd4ac268d672
cb29807a-92ec-4f8f-8966-0a5504548d19	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	36eeab00-16ef-4cb7-9f43-1626bfe6aae2
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	36eeab00-16ef-4cb7-9f43-1626bfe6aae2
3f6e599e-0aa0-4d36-81ad-dbcbace13f2f	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	36eeab00-16ef-4cb7-9f43-1626bfe6aae2
3de03083-9f1a-4fee-b76a-8a464b4689c8	role list	saml	saml-role-list-mapper	\N	445e57d8-6cb8-49a7-a566-480c1b754409
828ba905-f502-4e9a-b531-42fd14290041	address	openid-connect	oidc-address-mapper	\N	c32f274c-e449-4afe-bb2f-8cd75d24207d
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	avni-service-audience	openid-connect	oidc-audience-mapper	\N	fa931807-b3af-4ae0-81b7-267055627626
838a8c95-e6ff-466f-accd-e2d891901f00	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
0d400723-54ed-4379-b560-5330d718d8b2	full name	openid-connect	oidc-full-name-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
488e7cd9-2dae-41a1-ad81-09f934273ac9	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
9796fa98-06e7-4e85-a720-3382778bea21	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
0e8f93cd-4bfe-4dd1-a519-50596e20c289	given name	openid-connect	oidc-usermodel-property-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	website	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
2882bede-5489-4338-87a0-aa3de0cf20ae	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
8d85e784-ea8d-4d21-a78b-e3a08db7c847	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
2ece4931-9f38-4d06-8841-3d08dfc7153c	family name	openid-connect	oidc-usermodel-property-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
0fbdfa9f-58da-4d11-a94c-6290d8542f08	username	openid-connect	oidc-usermodel-property-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
89417ce2-f8f4-42e8-b117-529febfdaca9	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
10ac7431-86ab-45ec-8bf8-3a08001e63fc	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
f0436fb7-ae5a-4be2-b147-2826d6ed6750	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
10c7a76d-0feb-4ef9-a424-708b58ab1224	audience resolve	openid-connect	oidc-audience-resolve-mapper	63e63428-fdea-4672-8e4f-d7a4df56393f	\N
1616b5cc-bac8-40c1-8601-0c2e89c08df8	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	4381c433-5988-418a-bc71-177bb46e873a	\N
e31728b0-a369-41b8-b964-bd0e596f2a4c	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	4381c433-5988-418a-bc71-177bb46e873a	\N
edb01d0b-1d97-42d8-8f16-4ea59b40a523	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	4381c433-5988-418a-bc71-177bb46e873a	\N
71e84e97-63ee-4953-9a85-e37026f5c07d	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
a832dff7-e378-4a7e-ab25-b198aa36e901	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
febab41d-a1e4-46fb-adab-5581d1d4c71e	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	userUUID	openid-connect	oidc-usermodel-attribute-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
47ddea50-e388-4d57-8e81-a4e7c3430e94	locale	openid-connect	oidc-usermodel-attribute-mapper	f355103f-48b5-4615-adb5-9992c317295c	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
b687a1cf-9126-42d3-9363-d05d4fdaa7fd	true	userinfo.token.claim
b687a1cf-9126-42d3-9363-d05d4fdaa7fd	locale	user.attribute
b687a1cf-9126-42d3-9363-d05d4fdaa7fd	true	id.token.claim
b687a1cf-9126-42d3-9363-d05d4fdaa7fd	true	access.token.claim
b687a1cf-9126-42d3-9363-d05d4fdaa7fd	locale	claim.name
b687a1cf-9126-42d3-9363-d05d4fdaa7fd	String	jsonType.label
f9240e77-6d41-4a5f-9171-dd0788d575ae	false	single
f9240e77-6d41-4a5f-9171-dd0788d575ae	Basic	attribute.nameformat
f9240e77-6d41-4a5f-9171-dd0788d575ae	Role	attribute.name
254ca24a-b3a1-4287-ba3e-13b740e104bd	true	userinfo.token.claim
254ca24a-b3a1-4287-ba3e-13b740e104bd	nickname	user.attribute
254ca24a-b3a1-4287-ba3e-13b740e104bd	true	id.token.claim
254ca24a-b3a1-4287-ba3e-13b740e104bd	true	access.token.claim
254ca24a-b3a1-4287-ba3e-13b740e104bd	nickname	claim.name
254ca24a-b3a1-4287-ba3e-13b740e104bd	String	jsonType.label
357463ec-9b65-45da-94ca-5077169e516d	true	userinfo.token.claim
357463ec-9b65-45da-94ca-5077169e516d	updatedAt	user.attribute
357463ec-9b65-45da-94ca-5077169e516d	true	id.token.claim
357463ec-9b65-45da-94ca-5077169e516d	true	access.token.claim
357463ec-9b65-45da-94ca-5077169e516d	updated_at	claim.name
357463ec-9b65-45da-94ca-5077169e516d	long	jsonType.label
38237243-a17b-45e2-aa64-c9416b3dcaa7	true	userinfo.token.claim
38237243-a17b-45e2-aa64-c9416b3dcaa7	firstName	user.attribute
38237243-a17b-45e2-aa64-c9416b3dcaa7	true	id.token.claim
38237243-a17b-45e2-aa64-c9416b3dcaa7	true	access.token.claim
38237243-a17b-45e2-aa64-c9416b3dcaa7	given_name	claim.name
38237243-a17b-45e2-aa64-c9416b3dcaa7	String	jsonType.label
39372e77-95d2-4e0a-95e2-07e844528e6a	true	userinfo.token.claim
39372e77-95d2-4e0a-95e2-07e844528e6a	birthdate	user.attribute
39372e77-95d2-4e0a-95e2-07e844528e6a	true	id.token.claim
39372e77-95d2-4e0a-95e2-07e844528e6a	true	access.token.claim
39372e77-95d2-4e0a-95e2-07e844528e6a	birthdate	claim.name
39372e77-95d2-4e0a-95e2-07e844528e6a	String	jsonType.label
623910df-77b8-487a-b99e-2df4e7794e6f	true	userinfo.token.claim
623910df-77b8-487a-b99e-2df4e7794e6f	profile	user.attribute
623910df-77b8-487a-b99e-2df4e7794e6f	true	id.token.claim
623910df-77b8-487a-b99e-2df4e7794e6f	true	access.token.claim
623910df-77b8-487a-b99e-2df4e7794e6f	profile	claim.name
623910df-77b8-487a-b99e-2df4e7794e6f	String	jsonType.label
981548f0-b411-47de-830b-a500b78cb1bf	true	userinfo.token.claim
981548f0-b411-47de-830b-a500b78cb1bf	gender	user.attribute
981548f0-b411-47de-830b-a500b78cb1bf	true	id.token.claim
981548f0-b411-47de-830b-a500b78cb1bf	true	access.token.claim
981548f0-b411-47de-830b-a500b78cb1bf	gender	claim.name
981548f0-b411-47de-830b-a500b78cb1bf	String	jsonType.label
ab7d212a-c490-41ca-ae79-b3da584b9d8f	true	userinfo.token.claim
ab7d212a-c490-41ca-ae79-b3da584b9d8f	middleName	user.attribute
ab7d212a-c490-41ca-ae79-b3da584b9d8f	true	id.token.claim
ab7d212a-c490-41ca-ae79-b3da584b9d8f	true	access.token.claim
ab7d212a-c490-41ca-ae79-b3da584b9d8f	middle_name	claim.name
ab7d212a-c490-41ca-ae79-b3da584b9d8f	String	jsonType.label
ac51e3b2-0555-4dd5-95d6-7e8404e32226	true	userinfo.token.claim
ac51e3b2-0555-4dd5-95d6-7e8404e32226	picture	user.attribute
ac51e3b2-0555-4dd5-95d6-7e8404e32226	true	id.token.claim
ac51e3b2-0555-4dd5-95d6-7e8404e32226	true	access.token.claim
ac51e3b2-0555-4dd5-95d6-7e8404e32226	picture	claim.name
ac51e3b2-0555-4dd5-95d6-7e8404e32226	String	jsonType.label
b128be00-fadb-49f5-8447-5d5acb380397	true	userinfo.token.claim
b128be00-fadb-49f5-8447-5d5acb380397	lastName	user.attribute
b128be00-fadb-49f5-8447-5d5acb380397	true	id.token.claim
b128be00-fadb-49f5-8447-5d5acb380397	true	access.token.claim
b128be00-fadb-49f5-8447-5d5acb380397	family_name	claim.name
b128be00-fadb-49f5-8447-5d5acb380397	String	jsonType.label
bd628834-c40a-49e0-855d-00fd771dcdbb	true	userinfo.token.claim
bd628834-c40a-49e0-855d-00fd771dcdbb	username	user.attribute
bd628834-c40a-49e0-855d-00fd771dcdbb	true	id.token.claim
bd628834-c40a-49e0-855d-00fd771dcdbb	true	access.token.claim
bd628834-c40a-49e0-855d-00fd771dcdbb	preferred_username	claim.name
bd628834-c40a-49e0-855d-00fd771dcdbb	String	jsonType.label
ce4642d0-7d4f-4347-a797-95935dd23b73	true	userinfo.token.claim
ce4642d0-7d4f-4347-a797-95935dd23b73	true	id.token.claim
ce4642d0-7d4f-4347-a797-95935dd23b73	true	access.token.claim
d1f2b246-e790-4a09-9a09-158211a8596a	true	userinfo.token.claim
d1f2b246-e790-4a09-9a09-158211a8596a	website	user.attribute
d1f2b246-e790-4a09-9a09-158211a8596a	true	id.token.claim
d1f2b246-e790-4a09-9a09-158211a8596a	true	access.token.claim
d1f2b246-e790-4a09-9a09-158211a8596a	website	claim.name
d1f2b246-e790-4a09-9a09-158211a8596a	String	jsonType.label
ea395d5a-ccc3-43a4-a34a-031327954d3d	true	userinfo.token.claim
ea395d5a-ccc3-43a4-a34a-031327954d3d	zoneinfo	user.attribute
ea395d5a-ccc3-43a4-a34a-031327954d3d	true	id.token.claim
ea395d5a-ccc3-43a4-a34a-031327954d3d	true	access.token.claim
ea395d5a-ccc3-43a4-a34a-031327954d3d	zoneinfo	claim.name
ea395d5a-ccc3-43a4-a34a-031327954d3d	String	jsonType.label
f7bd06d9-2604-42bc-8e46-8928be942913	true	userinfo.token.claim
f7bd06d9-2604-42bc-8e46-8928be942913	locale	user.attribute
f7bd06d9-2604-42bc-8e46-8928be942913	true	id.token.claim
f7bd06d9-2604-42bc-8e46-8928be942913	true	access.token.claim
f7bd06d9-2604-42bc-8e46-8928be942913	locale	claim.name
f7bd06d9-2604-42bc-8e46-8928be942913	String	jsonType.label
820e79ab-422f-4253-828a-89273dcf0b4b	true	userinfo.token.claim
820e79ab-422f-4253-828a-89273dcf0b4b	email	user.attribute
820e79ab-422f-4253-828a-89273dcf0b4b	true	id.token.claim
820e79ab-422f-4253-828a-89273dcf0b4b	true	access.token.claim
820e79ab-422f-4253-828a-89273dcf0b4b	email	claim.name
820e79ab-422f-4253-828a-89273dcf0b4b	String	jsonType.label
c3e9b475-23b1-4a68-bc72-ccd23f6891d8	true	userinfo.token.claim
c3e9b475-23b1-4a68-bc72-ccd23f6891d8	emailVerified	user.attribute
c3e9b475-23b1-4a68-bc72-ccd23f6891d8	true	id.token.claim
c3e9b475-23b1-4a68-bc72-ccd23f6891d8	true	access.token.claim
c3e9b475-23b1-4a68-bc72-ccd23f6891d8	email_verified	claim.name
c3e9b475-23b1-4a68-bc72-ccd23f6891d8	boolean	jsonType.label
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	formatted	user.attribute.formatted
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	country	user.attribute.country
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	postal_code	user.attribute.postal_code
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	true	userinfo.token.claim
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	street	user.attribute.street
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	true	id.token.claim
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	region	user.attribute.region
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	true	access.token.claim
cfe1d1df-bdf5-4c34-b403-a51ee7ae94cf	locality	user.attribute.locality
3d640ec8-81ae-4648-8d5a-219d271277d1	true	userinfo.token.claim
3d640ec8-81ae-4648-8d5a-219d271277d1	phoneNumber	user.attribute
3d640ec8-81ae-4648-8d5a-219d271277d1	true	id.token.claim
3d640ec8-81ae-4648-8d5a-219d271277d1	true	access.token.claim
3d640ec8-81ae-4648-8d5a-219d271277d1	phone_number	claim.name
3d640ec8-81ae-4648-8d5a-219d271277d1	String	jsonType.label
e89c0bf0-0526-44a8-b4bc-3ea5a427db55	true	userinfo.token.claim
e89c0bf0-0526-44a8-b4bc-3ea5a427db55	phoneNumberVerified	user.attribute
e89c0bf0-0526-44a8-b4bc-3ea5a427db55	true	id.token.claim
e89c0bf0-0526-44a8-b4bc-3ea5a427db55	true	access.token.claim
e89c0bf0-0526-44a8-b4bc-3ea5a427db55	phone_number_verified	claim.name
e89c0bf0-0526-44a8-b4bc-3ea5a427db55	boolean	jsonType.label
bd3ce471-db5e-4e94-93cb-b6078520246e	true	multivalued
bd3ce471-db5e-4e94-93cb-b6078520246e	foo	user.attribute
bd3ce471-db5e-4e94-93cb-b6078520246e	true	access.token.claim
bd3ce471-db5e-4e94-93cb-b6078520246e	realm_access.roles	claim.name
bd3ce471-db5e-4e94-93cb-b6078520246e	String	jsonType.label
e99a5d2b-9482-475b-93c9-3e29079eac1f	true	multivalued
e99a5d2b-9482-475b-93c9-3e29079eac1f	foo	user.attribute
e99a5d2b-9482-475b-93c9-3e29079eac1f	true	access.token.claim
e99a5d2b-9482-475b-93c9-3e29079eac1f	resource_access.${client_id}.roles	claim.name
e99a5d2b-9482-475b-93c9-3e29079eac1f	String	jsonType.label
7753e5e2-43d2-4d1a-8c8d-dd9217b559df	true	multivalued
7753e5e2-43d2-4d1a-8c8d-dd9217b559df	foo	user.attribute
7753e5e2-43d2-4d1a-8c8d-dd9217b559df	true	id.token.claim
7753e5e2-43d2-4d1a-8c8d-dd9217b559df	true	access.token.claim
7753e5e2-43d2-4d1a-8c8d-dd9217b559df	groups	claim.name
7753e5e2-43d2-4d1a-8c8d-dd9217b559df	String	jsonType.label
f94264f6-dd99-4aa3-b97d-c7b8825e69cd	true	userinfo.token.claim
f94264f6-dd99-4aa3-b97d-c7b8825e69cd	username	user.attribute
f94264f6-dd99-4aa3-b97d-c7b8825e69cd	true	id.token.claim
f94264f6-dd99-4aa3-b97d-c7b8825e69cd	true	access.token.claim
f94264f6-dd99-4aa3-b97d-c7b8825e69cd	upn	claim.name
f94264f6-dd99-4aa3-b97d-c7b8825e69cd	String	jsonType.label
4eb261f7-48b2-477f-b37c-0c1eb0ecbbf1	true	id.token.claim
4eb261f7-48b2-477f-b37c-0c1eb0ecbbf1	true	access.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	true	userinfo.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	phoneNumber	user.attribute
387125c5-5735-482d-b6c1-cb8cd02848f2	true	id.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	true	access.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	phone_number	claim.name
387125c5-5735-482d-b6c1-cb8cd02848f2	String	jsonType.label
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	true	userinfo.token.claim
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	phoneNumberVerified	user.attribute
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	true	id.token.claim
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	true	access.token.claim
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	phone_number_verified	claim.name
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	boolean	jsonType.label
0132cd45-2832-4fb2-b3da-deb2bde01f7b	true	userinfo.token.claim
0132cd45-2832-4fb2-b3da-deb2bde01f7b	email	user.attribute
0132cd45-2832-4fb2-b3da-deb2bde01f7b	true	id.token.claim
0132cd45-2832-4fb2-b3da-deb2bde01f7b	true	access.token.claim
0132cd45-2832-4fb2-b3da-deb2bde01f7b	email	claim.name
0132cd45-2832-4fb2-b3da-deb2bde01f7b	String	jsonType.label
ec55de66-9ba8-401b-81a6-648deaa4dcdb	true	userinfo.token.claim
ec55de66-9ba8-401b-81a6-648deaa4dcdb	emailVerified	user.attribute
ec55de66-9ba8-401b-81a6-648deaa4dcdb	true	id.token.claim
ec55de66-9ba8-401b-81a6-648deaa4dcdb	true	access.token.claim
ec55de66-9ba8-401b-81a6-648deaa4dcdb	email_verified	claim.name
ec55de66-9ba8-401b-81a6-648deaa4dcdb	boolean	jsonType.label
016d0122-6dff-486c-b1ac-6417db3b7c16	true	multivalued
016d0122-6dff-486c-b1ac-6417db3b7c16	true	userinfo.token.claim
016d0122-6dff-486c-b1ac-6417db3b7c16	foo	user.attribute
016d0122-6dff-486c-b1ac-6417db3b7c16	true	id.token.claim
016d0122-6dff-486c-b1ac-6417db3b7c16	true	access.token.claim
016d0122-6dff-486c-b1ac-6417db3b7c16	groups	claim.name
016d0122-6dff-486c-b1ac-6417db3b7c16	String	jsonType.label
9015add1-eb40-4c3e-975e-bdd82293e7ce	true	userinfo.token.claim
9015add1-eb40-4c3e-975e-bdd82293e7ce	username	user.attribute
9015add1-eb40-4c3e-975e-bdd82293e7ce	true	id.token.claim
9015add1-eb40-4c3e-975e-bdd82293e7ce	true	access.token.claim
9015add1-eb40-4c3e-975e-bdd82293e7ce	upn	claim.name
9015add1-eb40-4c3e-975e-bdd82293e7ce	String	jsonType.label
2acd9feb-49ca-42f5-ad96-70cd81d217e5	true	id.token.claim
2acd9feb-49ca-42f5-ad96-70cd81d217e5	true	access.token.claim
2acd9feb-49ca-42f5-ad96-70cd81d217e5	true	userinfo.token.claim
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	foo	user.attribute
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	true	access.token.claim
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	resource_access.${client_id}.roles	claim.name
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	String	jsonType.label
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	true	multivalued
cb29807a-92ec-4f8f-8966-0a5504548d19	foo	user.attribute
cb29807a-92ec-4f8f-8966-0a5504548d19	true	access.token.claim
cb29807a-92ec-4f8f-8966-0a5504548d19	realm_access.roles	claim.name
cb29807a-92ec-4f8f-8966-0a5504548d19	String	jsonType.label
cb29807a-92ec-4f8f-8966-0a5504548d19	true	multivalued
3de03083-9f1a-4fee-b76a-8a464b4689c8	false	single
3de03083-9f1a-4fee-b76a-8a464b4689c8	Basic	attribute.nameformat
3de03083-9f1a-4fee-b76a-8a464b4689c8	Role	attribute.name
828ba905-f502-4e9a-b531-42fd14290041	formatted	user.attribute.formatted
828ba905-f502-4e9a-b531-42fd14290041	country	user.attribute.country
828ba905-f502-4e9a-b531-42fd14290041	postal_code	user.attribute.postal_code
828ba905-f502-4e9a-b531-42fd14290041	true	userinfo.token.claim
828ba905-f502-4e9a-b531-42fd14290041	street	user.attribute.street
828ba905-f502-4e9a-b531-42fd14290041	true	id.token.claim
828ba905-f502-4e9a-b531-42fd14290041	region	user.attribute.region
828ba905-f502-4e9a-b531-42fd14290041	true	access.token.claim
828ba905-f502-4e9a-b531-42fd14290041	locality	user.attribute.locality
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	avni-server	included.client.audience
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	false	id.token.claim
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	true	access.token.claim
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	false	userinfo.token.claim
0d400723-54ed-4379-b560-5330d718d8b2	true	id.token.claim
0d400723-54ed-4379-b560-5330d718d8b2	true	access.token.claim
0d400723-54ed-4379-b560-5330d718d8b2	true	userinfo.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	true	userinfo.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	firstName	user.attribute
0e8f93cd-4bfe-4dd1-a519-50596e20c289	true	id.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	true	access.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	given_name	claim.name
0e8f93cd-4bfe-4dd1-a519-50596e20c289	String	jsonType.label
0fbdfa9f-58da-4d11-a94c-6290d8542f08	true	userinfo.token.claim
0fbdfa9f-58da-4d11-a94c-6290d8542f08	username	user.attribute
0fbdfa9f-58da-4d11-a94c-6290d8542f08	true	id.token.claim
0fbdfa9f-58da-4d11-a94c-6290d8542f08	true	access.token.claim
0fbdfa9f-58da-4d11-a94c-6290d8542f08	preferred_username	claim.name
0fbdfa9f-58da-4d11-a94c-6290d8542f08	String	jsonType.label
10ac7431-86ab-45ec-8bf8-3a08001e63fc	true	userinfo.token.claim
10ac7431-86ab-45ec-8bf8-3a08001e63fc	updatedAt	user.attribute
10ac7431-86ab-45ec-8bf8-3a08001e63fc	true	id.token.claim
10ac7431-86ab-45ec-8bf8-3a08001e63fc	true	access.token.claim
10ac7431-86ab-45ec-8bf8-3a08001e63fc	updated_at	claim.name
10ac7431-86ab-45ec-8bf8-3a08001e63fc	long	jsonType.label
2882bede-5489-4338-87a0-aa3de0cf20ae	true	userinfo.token.claim
2882bede-5489-4338-87a0-aa3de0cf20ae	birthdate	user.attribute
2882bede-5489-4338-87a0-aa3de0cf20ae	true	id.token.claim
2882bede-5489-4338-87a0-aa3de0cf20ae	true	access.token.claim
2882bede-5489-4338-87a0-aa3de0cf20ae	birthdate	claim.name
2882bede-5489-4338-87a0-aa3de0cf20ae	String	jsonType.label
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	true	userinfo.token.claim
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	website	user.attribute
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	true	id.token.claim
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	true	access.token.claim
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	website	claim.name
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	String	jsonType.label
2ece4931-9f38-4d06-8841-3d08dfc7153c	true	userinfo.token.claim
2ece4931-9f38-4d06-8841-3d08dfc7153c	lastName	user.attribute
2ece4931-9f38-4d06-8841-3d08dfc7153c	true	id.token.claim
2ece4931-9f38-4d06-8841-3d08dfc7153c	true	access.token.claim
2ece4931-9f38-4d06-8841-3d08dfc7153c	family_name	claim.name
2ece4931-9f38-4d06-8841-3d08dfc7153c	String	jsonType.label
488e7cd9-2dae-41a1-ad81-09f934273ac9	true	userinfo.token.claim
488e7cd9-2dae-41a1-ad81-09f934273ac9	zoneinfo	user.attribute
488e7cd9-2dae-41a1-ad81-09f934273ac9	true	id.token.claim
488e7cd9-2dae-41a1-ad81-09f934273ac9	true	access.token.claim
488e7cd9-2dae-41a1-ad81-09f934273ac9	zoneinfo	claim.name
488e7cd9-2dae-41a1-ad81-09f934273ac9	String	jsonType.label
838a8c95-e6ff-466f-accd-e2d891901f00	true	userinfo.token.claim
838a8c95-e6ff-466f-accd-e2d891901f00	middleName	user.attribute
838a8c95-e6ff-466f-accd-e2d891901f00	true	id.token.claim
838a8c95-e6ff-466f-accd-e2d891901f00	true	access.token.claim
838a8c95-e6ff-466f-accd-e2d891901f00	middle_name	claim.name
838a8c95-e6ff-466f-accd-e2d891901f00	String	jsonType.label
89417ce2-f8f4-42e8-b117-529febfdaca9	true	userinfo.token.claim
89417ce2-f8f4-42e8-b117-529febfdaca9	profile	user.attribute
89417ce2-f8f4-42e8-b117-529febfdaca9	true	id.token.claim
89417ce2-f8f4-42e8-b117-529febfdaca9	true	access.token.claim
89417ce2-f8f4-42e8-b117-529febfdaca9	profile	claim.name
89417ce2-f8f4-42e8-b117-529febfdaca9	String	jsonType.label
8d85e784-ea8d-4d21-a78b-e3a08db7c847	true	userinfo.token.claim
8d85e784-ea8d-4d21-a78b-e3a08db7c847	gender	user.attribute
8d85e784-ea8d-4d21-a78b-e3a08db7c847	true	id.token.claim
8d85e784-ea8d-4d21-a78b-e3a08db7c847	true	access.token.claim
8d85e784-ea8d-4d21-a78b-e3a08db7c847	gender	claim.name
8d85e784-ea8d-4d21-a78b-e3a08db7c847	String	jsonType.label
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	true	userinfo.token.claim
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	picture	user.attribute
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	true	id.token.claim
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	true	access.token.claim
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	picture	claim.name
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	String	jsonType.label
9796fa98-06e7-4e85-a720-3382778bea21	true	userinfo.token.claim
9796fa98-06e7-4e85-a720-3382778bea21	locale	user.attribute
9796fa98-06e7-4e85-a720-3382778bea21	true	id.token.claim
9796fa98-06e7-4e85-a720-3382778bea21	true	access.token.claim
9796fa98-06e7-4e85-a720-3382778bea21	locale	claim.name
9796fa98-06e7-4e85-a720-3382778bea21	String	jsonType.label
f0436fb7-ae5a-4be2-b147-2826d6ed6750	true	userinfo.token.claim
f0436fb7-ae5a-4be2-b147-2826d6ed6750	nickname	user.attribute
f0436fb7-ae5a-4be2-b147-2826d6ed6750	true	id.token.claim
f0436fb7-ae5a-4be2-b147-2826d6ed6750	true	access.token.claim
f0436fb7-ae5a-4be2-b147-2826d6ed6750	nickname	claim.name
f0436fb7-ae5a-4be2-b147-2826d6ed6750	String	jsonType.label
1616b5cc-bac8-40c1-8601-0c2e89c08df8	clientHost	user.session.note
1616b5cc-bac8-40c1-8601-0c2e89c08df8	true	userinfo.token.claim
1616b5cc-bac8-40c1-8601-0c2e89c08df8	true	id.token.claim
1616b5cc-bac8-40c1-8601-0c2e89c08df8	true	access.token.claim
1616b5cc-bac8-40c1-8601-0c2e89c08df8	clientHost	claim.name
1616b5cc-bac8-40c1-8601-0c2e89c08df8	String	jsonType.label
e31728b0-a369-41b8-b964-bd0e596f2a4c	clientId	user.session.note
e31728b0-a369-41b8-b964-bd0e596f2a4c	true	userinfo.token.claim
e31728b0-a369-41b8-b964-bd0e596f2a4c	true	id.token.claim
e31728b0-a369-41b8-b964-bd0e596f2a4c	true	access.token.claim
e31728b0-a369-41b8-b964-bd0e596f2a4c	clientId	claim.name
e31728b0-a369-41b8-b964-bd0e596f2a4c	String	jsonType.label
edb01d0b-1d97-42d8-8f16-4ea59b40a523	clientAddress	user.session.note
edb01d0b-1d97-42d8-8f16-4ea59b40a523	true	userinfo.token.claim
edb01d0b-1d97-42d8-8f16-4ea59b40a523	true	id.token.claim
edb01d0b-1d97-42d8-8f16-4ea59b40a523	true	access.token.claim
edb01d0b-1d97-42d8-8f16-4ea59b40a523	clientAddress	claim.name
edb01d0b-1d97-42d8-8f16-4ea59b40a523	String	jsonType.label
71e84e97-63ee-4953-9a85-e37026f5c07d	clientHost	user.session.note
71e84e97-63ee-4953-9a85-e37026f5c07d	true	userinfo.token.claim
71e84e97-63ee-4953-9a85-e37026f5c07d	true	id.token.claim
71e84e97-63ee-4953-9a85-e37026f5c07d	true	access.token.claim
71e84e97-63ee-4953-9a85-e37026f5c07d	clientHost	claim.name
71e84e97-63ee-4953-9a85-e37026f5c07d	String	jsonType.label
a832dff7-e378-4a7e-ab25-b198aa36e901	clientAddress	user.session.note
a832dff7-e378-4a7e-ab25-b198aa36e901	true	userinfo.token.claim
a832dff7-e378-4a7e-ab25-b198aa36e901	true	id.token.claim
a832dff7-e378-4a7e-ab25-b198aa36e901	true	access.token.claim
a832dff7-e378-4a7e-ab25-b198aa36e901	clientAddress	claim.name
a832dff7-e378-4a7e-ab25-b198aa36e901	String	jsonType.label
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	true	userinfo.token.claim
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	custom:userUUID	user.attribute
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	true	id.token.claim
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	true	access.token.claim
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	custom:userUUID	claim.name
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	String	jsonType.label
febab41d-a1e4-46fb-adab-5581d1d4c71e	clientId	user.session.note
febab41d-a1e4-46fb-adab-5581d1d4c71e	true	userinfo.token.claim
febab41d-a1e4-46fb-adab-5581d1d4c71e	true	id.token.claim
febab41d-a1e4-46fb-adab-5581d1d4c71e	true	access.token.claim
febab41d-a1e4-46fb-adab-5581d1d4c71e	clientId	claim.name
febab41d-a1e4-46fb-adab-5581d1d4c71e	String	jsonType.label
47ddea50-e388-4d57-8e81-a4e7c3430e94	true	userinfo.token.claim
47ddea50-e388-4d57-8e81-a4e7c3430e94	locale	user.attribute
47ddea50-e388-4d57-8e81-a4e7c3430e94	true	id.token.claim
47ddea50-e388-4d57-8e81-a4e7c3430e94	true	access.token.claim
47ddea50-e388-4d57-8e81-a4e7c3430e94	locale	claim.name
47ddea50-e388-4d57-8e81-a4e7c3430e94	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
5ed7970f-211a-4f6b-8938-f50938e90423	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	64b186bc-71c6-464e-9796-0387b69e11a3	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	aaca34f0-1c81-4ecf-aae1-0ae0b8e03c2e	5911543b-b1eb-4a6a-82ae-5e76e78113cc	5f98c1c7-a09a-4d60-885c-b68570411531	62cdd1f1-5196-45aa-afdc-0bf37b1d55d7	50017cdf-3f44-450b-b161-6032f6e22ac7	2592000	f	900	t	f	f2d1872d-3922-473a-8a20-fed5318b2bd5	0	f	0	0	3bc8c148-0469-4816-b175-b6cee105a940
On-premise	60	300	300	\N	\N	\N	t	f	0	\N	On-premise	0	\N	f	f	f	f	EXTERNAL	2592000	2592000	f	f	1cd1fe85-ab12-4b77-91b8-6e27990a63b5	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	f8d52b1f-686d-46e1-b3bf-9f9fc86a7f31	55e21239-1f6a-402f-974c-61bdbf0fa5ed	72337b4c-1e9c-4e26-9108-5f3f7eac44e0	02ef3ef4-61ec-4afe-89cf-8f91f67faa27	ae23e0c1-c7dd-4231-b791-57ca496962db	2592000	f	900	t	f	a5bcaf47-524d-4489-9fae-3afca40d5f66	0	f	0	0	69c368f8-4e0e-4420-93e7-918f504378e4
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	5ed7970f-211a-4f6b-8938-f50938e90423	
_browser_header.xContentTypeOptions	5ed7970f-211a-4f6b-8938-f50938e90423	nosniff
_browser_header.xRobotsTag	5ed7970f-211a-4f6b-8938-f50938e90423	none
_browser_header.xFrameOptions	5ed7970f-211a-4f6b-8938-f50938e90423	SAMEORIGIN
_browser_header.contentSecurityPolicy	5ed7970f-211a-4f6b-8938-f50938e90423	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	5ed7970f-211a-4f6b-8938-f50938e90423	1; mode=block
_browser_header.strictTransportSecurity	5ed7970f-211a-4f6b-8938-f50938e90423	max-age=31536000; includeSubDomains
bruteForceProtected	5ed7970f-211a-4f6b-8938-f50938e90423	false
permanentLockout	5ed7970f-211a-4f6b-8938-f50938e90423	false
maxFailureWaitSeconds	5ed7970f-211a-4f6b-8938-f50938e90423	900
minimumQuickLoginWaitSeconds	5ed7970f-211a-4f6b-8938-f50938e90423	60
waitIncrementSeconds	5ed7970f-211a-4f6b-8938-f50938e90423	60
quickLoginCheckMilliSeconds	5ed7970f-211a-4f6b-8938-f50938e90423	1000
maxDeltaTimeSeconds	5ed7970f-211a-4f6b-8938-f50938e90423	43200
failureFactor	5ed7970f-211a-4f6b-8938-f50938e90423	30
realmReusableOtpCode	5ed7970f-211a-4f6b-8938-f50938e90423	false
displayName	5ed7970f-211a-4f6b-8938-f50938e90423	Keycloak
displayNameHtml	5ed7970f-211a-4f6b-8938-f50938e90423	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	5ed7970f-211a-4f6b-8938-f50938e90423	RS256
offlineSessionMaxLifespanEnabled	5ed7970f-211a-4f6b-8938-f50938e90423	false
offlineSessionMaxLifespan	5ed7970f-211a-4f6b-8938-f50938e90423	5184000
_browser_header.contentSecurityPolicyReportOnly	On-premise	
_browser_header.xContentTypeOptions	On-premise	nosniff
_browser_header.xRobotsTag	On-premise	none
_browser_header.xFrameOptions	On-premise	SAMEORIGIN
_browser_header.contentSecurityPolicy	On-premise	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	On-premise	1; mode=block
_browser_header.strictTransportSecurity	On-premise	max-age=31536000; includeSubDomains
bruteForceProtected	On-premise	false
permanentLockout	On-premise	false
maxFailureWaitSeconds	On-premise	900
minimumQuickLoginWaitSeconds	On-premise	60
waitIncrementSeconds	On-premise	60
quickLoginCheckMilliSeconds	On-premise	1000
maxDeltaTimeSeconds	On-premise	43200
failureFactor	On-premise	30
realmReusableOtpCode	On-premise	false
displayName	On-premise	On-premise
defaultSignatureAlgorithm	On-premise	RS256
offlineSessionMaxLifespanEnabled	On-premise	false
offlineSessionMaxLifespan	On-premise	5184000
clientSessionIdleTimeout	On-premise	0
clientSessionMaxLifespan	On-premise	0
clientOfflineSessionIdleTimeout	On-premise	0
clientOfflineSessionMaxLifespan	On-premise	0
actionTokenGeneratedByAdminLifespan	On-premise	43200
actionTokenGeneratedByUserLifespan	On-premise	300
oauth2DeviceCodeLifespan	On-premise	300
oauth2DevicePollingInterval	On-premise	5
webAuthnPolicyRpEntityName	On-premise	keycloak
webAuthnPolicySignatureAlgorithms	On-premise	ES256
webAuthnPolicyRpId	On-premise	
webAuthnPolicyAttestationConveyancePreference	On-premise	not specified
webAuthnPolicyAuthenticatorAttachment	On-premise	not specified
webAuthnPolicyRequireResidentKey	On-premise	not specified
webAuthnPolicyUserVerificationRequirement	On-premise	not specified
webAuthnPolicyCreateTimeout	On-premise	0
webAuthnPolicyAvoidSameAuthenticatorRegister	On-premise	false
webAuthnPolicyRpEntityNamePasswordless	On-premise	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	On-premise	ES256
webAuthnPolicyRpIdPasswordless	On-premise	
webAuthnPolicyAttestationConveyancePreferencePasswordless	On-premise	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	On-premise	not specified
webAuthnPolicyRequireResidentKeyPasswordless	On-premise	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	On-premise	not specified
webAuthnPolicyCreateTimeoutPasswordless	On-premise	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	On-premise	false
cibaBackchannelTokenDeliveryMode	On-premise	poll
cibaExpiresIn	On-premise	120
cibaInterval	On-premise	5
cibaAuthRequestedUserHint	On-premise	login_hint
parRequestUriLifespan	On-premise	60
userProfileEnabled	On-premise	false
client-policies.profiles	On-premise	{"profiles":[]}
client-policies.policies	On-premise	{"policies":[]}
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
5ed7970f-211a-4f6b-8938-f50938e90423	jboss-logging
On-premise	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	5ed7970f-211a-4f6b-8938-f50938e90423
password	password	t	t	On-premise
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.redirect_uris (client_id, value) FROM stdin;
c90eddfd-d7b2-49a1-8464-1ce9bc2d0f56	/realms/master/account/*
138412d0-f1d5-4a20-90b3-b5ce26d89b93	/realms/master/account/*
ca64abba-762f-4ffb-9423-6a53838c84a8	/admin/master/console/*
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	/realms/On-premise/account/*
63e63428-fdea-4672-8e4f-d7a4df56393f	/realms/On-premise/account/*
4381c433-5988-418a-bc71-177bb46e873a	http://localhost:8080/*
915277c7-706e-4aa8-ad41-dfc2c3818c0b	https://3.109.55.3:8022
f355103f-48b5-4615-adb5-9992c317295c	/admin/On-premise/console/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
4c3734bc-e166-47aa-a8de-580e182faa81	VERIFY_EMAIL	Verify Email	5ed7970f-211a-4f6b-8938-f50938e90423	t	f	VERIFY_EMAIL	50
bf5fdcc8-365a-42bb-a2f4-dfea0b3cf148	UPDATE_PROFILE	Update Profile	5ed7970f-211a-4f6b-8938-f50938e90423	t	f	UPDATE_PROFILE	40
d1a49667-e472-44f4-ac01-051fef42089a	CONFIGURE_TOTP	Configure OTP	5ed7970f-211a-4f6b-8938-f50938e90423	t	f	CONFIGURE_TOTP	10
0dca2d2c-194c-4b05-80be-670d31d31cb6	UPDATE_PASSWORD	Update Password	5ed7970f-211a-4f6b-8938-f50938e90423	t	f	UPDATE_PASSWORD	30
0aa32a7d-6abd-44c5-b169-0c25b9f25b56	terms_and_conditions	Terms and Conditions	5ed7970f-211a-4f6b-8938-f50938e90423	f	f	terms_and_conditions	20
09c775c6-f21e-4491-b064-fd79c4504d2f	delete_account	Delete Account	5ed7970f-211a-4f6b-8938-f50938e90423	f	f	delete_account	60
3a006b53-286b-4d4b-ab37-8500902aabfe	update_user_locale	Update User Locale	5ed7970f-211a-4f6b-8938-f50938e90423	t	f	update_user_locale	1000
58a7761d-9219-4ae0-a399-fe8393972b38	webauthn-register	Webauthn Register	5ed7970f-211a-4f6b-8938-f50938e90423	t	f	webauthn-register	70
fec63369-daa3-4949-a925-6b3f07beff66	webauthn-register-passwordless	Webauthn Register Passwordless	5ed7970f-211a-4f6b-8938-f50938e90423	t	f	webauthn-register-passwordless	80
d608acb6-0c01-4ae0-919c-94575124eda9	CONFIGURE_TOTP	Configure OTP	On-premise	t	f	CONFIGURE_TOTP	10
545fe1b1-64e4-4bc3-b8cc-5a48058bb904	delete_account	Delete Account	On-premise	f	f	delete_account	20
7c08994a-53e8-4c72-93a2-68cb37b8e142	terms_and_conditions	Terms and Conditions	On-premise	f	f	terms_and_conditions	30
e98ca905-0095-4485-984c-bb0c90940013	UPDATE_PASSWORD	Update Password	On-premise	t	f	UPDATE_PASSWORD	40
5d194b46-e348-4a5b-9bfa-cb3158098606	UPDATE_PROFILE	Update Profile	On-premise	t	f	UPDATE_PROFILE	50
f8de6249-122a-44a1-bfac-c2e6ba24bef0	update_user_locale	Update User Locale	On-premise	t	f	update_user_locale	60
70d573f5-008b-440f-9790-2898fca76945	VERIFY_EMAIL	Verify Email	On-premise	t	f	VERIFY_EMAIL	70
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
138412d0-f1d5-4a20-90b3-b5ce26d89b93	1713d146-25b9-4c95-9c76-8234d8f48e47
138412d0-f1d5-4a20-90b3-b5ce26d89b93	27c29c75-3b0d-46c9-abde-f232de68194c
63e63428-fdea-4672-8e4f-d7a4df56393f	2ee509b1-2f53-45ee-9673-d71e8e60a78a
63e63428-fdea-4672-8e4f-d7a4df56393f	01ded32e-7299-4877-b1de-ceab307fdf0d
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_attribute (name, value, user_id, id) FROM stdin;
custom:userUUID	5fed2907-df3a-4867-aef5-c87f4c78a31a	af0b953e-9b5d-40af-a8db-a1783bf291b8	8ff4a798-40ba-4c79-89f0-d5db9c6189f8
custom:userUUID	fbc6fe82-dcbe-4f2b-8eab-0ca6dd39e62b	e13e313c-352f-4db2-8db4-477273b39005	25a24358-bc8a-4faf-bee1-932f1fd23b92
phone_number_verified	true	e13e313c-352f-4db2-8db4-477273b39005	17f1f96e-c5b9-4f2c-abe5-39161618e064
phone_number	+919123456789	e13e313c-352f-4db2-8db4-477273b39005	771328c5-db24-49ee-9f0e-09d2702ed81e
custom:userUUID	ca8ae15d-d8e9-448a-8f95-ef7429059a5f	ed9756fb-0a0f-465d-940e-045d7e1dcdc8	e92cc649-0cda-4bb3-b483-c0e5a56cdb2f
phone_number_verified	true	ed9756fb-0a0f-465d-940e-045d7e1dcdc8	e34131c0-f0c3-4af8-a370-fd7cbedd3e76
phone_number	+919123456789	ed9756fb-0a0f-465d-940e-045d7e1dcdc8	ee17175e-6824-44ad-8a1d-44b7a13813bc
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
89b32370-7115-484c-8848-6ba37d872f18	\N	1a4e4ee9-6546-4503-82c9-78441a6322e0	f	t	\N	\N	\N	5ed7970f-211a-4f6b-8938-f50938e90423	keycloakadmin	1685432382985	\N	0
f72df378-c154-4cef-99f6-07c40621a687	\N	9a716d0f-1cb0-47df-8de6-74d0a25dee74	f	t	\N	\N	\N	On-premise	service-account-admin-api	1656653394420	4381c433-5988-418a-bc71-177bb46e873a	0
ba5388d5-f763-4fad-bfb8-edb9f4a33f88	\N	0cdc1a21-f42b-4feb-8350-e5087e7d6acf	f	t	\N	\N	\N	On-premise	service-account-avni-client	1685432458940	915277c7-706e-4aa8-ad41-dfc2c3818c0b	0
af0b953e-9b5d-40af-a8db-a1783bf291b8	admin@example.com	admin@example.com	t	t	\N	Admin	Admin	On-premise	admin	1685432697380	\N	0
e13e313c-352f-4db2-8db4-477273b39005	adminbahmni@example.com	adminbahmni@example.com	t	t	\N	Administrator	\N	On-premise	admin@bahmni	1685693389111	\N	0
ed9756fb-0a0f-465d-940e-045d7e1dcdc8	integration@example.com	integration@example.com	t	t	\N	Integration	\N	On-premise	integration@bahmni	1685693481530	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
3bc8c148-0469-4816-b175-b6cee105a940	89b32370-7115-484c-8848-6ba37d872f18
6d932167-119c-4477-84f1-fea7c845c74f	89b32370-7115-484c-8848-6ba37d872f18
69c368f8-4e0e-4420-93e7-918f504378e4	f72df378-c154-4cef-99f6-07c40621a687
69c368f8-4e0e-4420-93e7-918f504378e4	ba5388d5-f763-4fad-bfb8-edb9f4a33f88
e08be323-9f52-45c0-b7f7-8c82e024e517	89b32370-7115-484c-8848-6ba37d872f18
79f11bd9-197f-4f4c-823c-93d9e84a010a	89b32370-7115-484c-8848-6ba37d872f18
4fd5a695-aa42-4137-9e74-e8a493b105a9	89b32370-7115-484c-8848-6ba37d872f18
d3180af1-114f-4cf8-93f7-c79699d07d9f	89b32370-7115-484c-8848-6ba37d872f18
a44c9d37-6e47-46d9-bf11-661032d57fee	89b32370-7115-484c-8848-6ba37d872f18
24a53299-03c8-4680-ba2c-cc9962089925	89b32370-7115-484c-8848-6ba37d872f18
34acee9b-e1be-4386-9bc9-900a519799e8	89b32370-7115-484c-8848-6ba37d872f18
fa03af0c-fe71-4002-89cf-0180ed411aa9	89b32370-7115-484c-8848-6ba37d872f18
53891835-4632-4f7f-b636-f2af41177981	89b32370-7115-484c-8848-6ba37d872f18
9f0e3237-c077-493f-88ad-3efe8d91c32e	89b32370-7115-484c-8848-6ba37d872f18
8baf43bb-8c23-4395-969f-44a69a432271	89b32370-7115-484c-8848-6ba37d872f18
14dfb1d9-b8a7-4582-950e-7fbcfc90905c	89b32370-7115-484c-8848-6ba37d872f18
3b36c6d4-c6cc-4f20-b37c-d2381bbf12d6	89b32370-7115-484c-8848-6ba37d872f18
5521e737-7c5d-41b7-a780-9ae682a77d25	89b32370-7115-484c-8848-6ba37d872f18
17a7dd75-b56c-47e1-9070-ac31e7d79188	89b32370-7115-484c-8848-6ba37d872f18
b13f0fe8-4c62-4e5f-b65c-0d5ab97427a0	89b32370-7115-484c-8848-6ba37d872f18
882ef03b-86ce-4454-a22b-1aea267e1d78	89b32370-7115-484c-8848-6ba37d872f18
69c368f8-4e0e-4420-93e7-918f504378e4	af0b953e-9b5d-40af-a8db-a1783bf291b8
69c368f8-4e0e-4420-93e7-918f504378e4	e13e313c-352f-4db2-8db4-477273b39005
69c368f8-4e0e-4420-93e7-918f504378e4	ed9756fb-0a0f-465d-940e-045d7e1dcdc8
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.web_origins (client_id, value) FROM stdin;
ca64abba-762f-4ffb-9423-6a53838c84a8	+
4381c433-5988-418a-bc71-177bb46e873a	http://localhost:8080
915277c7-706e-4aa8-ad41-dfc2c3818c0b	*
f355103f-48b5-4615-adb5-9992c317295c	+
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

